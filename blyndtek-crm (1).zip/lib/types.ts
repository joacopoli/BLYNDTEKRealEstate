export type ServiceId = 
  | "dashboard"
  | "conversations" 
  | "leads"
  | "voice"
  | "valuations"
  | "documents"
  | "reports"
  | "analytics"
  | "billing"
  | "settings"

export interface User {
  id: string
  name: string
  email: string
  role: string
  company: string
  avatar?: string
  provider?: 'email' | 'google'
}

export interface Client {
  name: string
  phone: string
  email?: string
}

export interface Message {
  id: string
  sender: "client" | "ai" | "agent"
  content: string
  timestamp: Date
  type?: "text" | "image" | "file"
}

export interface Conversation {
  id: string
  client: Client
  messages: Message[]
  lastMessage: Message
  channel: "whatsapp" | "web" | "phone"
  aiEnabled: boolean
  isHumanTakeover: boolean
  hasUnreadMessages: boolean
  priority: "low" | "medium" | "high"
  tags: string[]
  assignedAgent?: string
  status?: "active" | "closed" | "pending"
}

export interface PropertyInterest {
  id: string
  type: "apartment" | "house" | "commercial"
  location: string
  budget: { min: number; max: number }
}

export interface Lead {
  id: string
  name: string
  phone: string
  email: string
  status: "new" | "contacted" | "qualified" | "proposal" | "closed" | "lost"
  score: number
  source: string
  propertyInterest: string
  budget: string
  lastActivity: Date
  createdAt: Date
  assignedTo?: string
  notes: string[]
  properties: PropertyInterest[]
}

export interface Property {
  id: string
  address: string
  type: "apartment" | "house" | "commercial"
  value: number
  confidence: number
  status: "pending" | "processing" | "completed" | "error"
  requestDate: Date
}

export interface Document {
  id: string
  name: string
  type: "contract" | "agreement" | "report" | "other"
  status: "draft" | "pending" | "signed" | "completed"
  clientName: string
  createdDate: Date
}

export interface Notification {
  id: string
  title: string
  message: string
  timestamp: Date
  read: boolean
  type: "info" | "success" | "warning" | "error"
}

export interface Report {
  id: string
  name: string
  type: string
  generatedDate: Date
  url: string
}

export interface Service {
  id: ServiceId
  name: string
  tier: string
  price: number
  isActive: boolean
  usage: number
  limit: number
  unit: string
  setupFee?: number
}

export interface UsageMetrics {
  period: "monthly" | "yearly"
  conversations: number
  voiceCalls: number
  valuations: number
  documents: number
  apiCalls: number
  storage: number
}

export interface PlanLimits {
  conversations: number
  voiceCalls: number
  users: number
  leads: number
  valuations: number
  documents: number
  storage: number
  apiCalls: number
}

export interface PlanTier {
  id: string
  name: string
  basePrice: number
  description: string
  features: string[]
  limits: PlanLimits
  popular?: boolean
}

export interface Company {
  id: string
  name: string
  plan: PlanTier
  services: Service[]
  usage: UsageMetrics
  limits: PlanLimits
  billing: {
    totalMonthly: number
    nextBillingDate: Date
    paymentMethod: {
      brand: string
      last4: string
      expiryMonth: string
      expiryYear: string
    }
    stripeCustomerId: string
    stripeSubscriptionId: string
    usage: UsageMetrics
  }
}

export interface Module {
  id: ServiceId
  name: string
  description: string
  isActive: boolean
}

export interface SystemSettings {
  globalAiEnabled: boolean
  webhookUrl: string
  whatsappApiKey: string
  supportEmail: string
  maintenanceMode: boolean
  allowNewRegistrations: boolean
  maxUsersPerCompany: number
  defaultPlan: string
  systemNotifications: {
    enabled: boolean
    channels: string[]
  }
}

export interface AppState {
  user: User | null
  company: Company | null
  isAuthenticated: boolean
  activeService: ServiceId
  conversations: Conversation[]
  selectedConversation: Conversation | null
  leads: Lead[]
  properties: Property[]
  documents: Document[]
  notifications: Notification[]
  reports: Report[]
  modules: Module[]
  systemSettings: SystemSettings
}

export type AppAction =
  | { type: "LOGIN"; payload: { email: string; name?: string; avatar?: string; provider?: 'email' | 'google' } }
  | { type: "LOGOUT" }
  | { type: "SET_ACTIVE_SERVICE"; payload: ServiceId }
  | { type: "ADD_SERVICE"; payload: Service }
  | { type: "SELECT_CONVERSATION"; payload: Conversation | null }
  | { type: "ADD_MESSAGE"; payload: { conversationId: string; message: Message } }
  | { type: "TOGGLE_AI"; payload: { conversationId: string; enabled: boolean } }
  | { type: "TOGGLE_MODULE"; payload: { moduleId: ServiceId; enabled: boolean } }
  | { type: "SET_SYSTEM_SETTINGS"; payload: SystemSettings }
  | { type: "UPGRADE_PLAN"; payload: { planId: string; services: Service[] } }
