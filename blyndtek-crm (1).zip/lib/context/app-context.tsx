"use client"

import type React from "react"
import { createContext, useContext, useReducer, type ReactNode } from "react"
import type { AppState, AppAction, Conversation, Report, PlanTier, UsageMetrics } from "@/lib/types"

const initialConversations: Conversation[] = [
  {
    id: "conv_001",
    client: { name: "María González", phone: "+34 600 123 456" },
    messages: [
      {
        id: "msg1",
        sender: "client",
        content: "Hola, estoy interesada en el piso de la Calle Goya.",
        timestamp: new Date(Date.now() - 600000),
      },
      {
        id: "msg2",
        sender: "ai",
        content: "¡Hola María! Claro, el piso de Calle Goya es una excelente opción. Tiene 3 habitaciones y 120m². ¿Te gustaría agendar una visita?",
        timestamp: new Date(Date.now() - 540000),
      },
      {
        id: "msg3",
        sender: "client",
        content: "Sí, por favor. ¿Qué horarios tienen disponibles?",
        timestamp: new Date(Date.now() - 300000),
      },
    ],
    lastMessage: {
      id: "msg3",
      sender: "client",
      content: "Sí, por favor. ¿Qué horarios tienen disponibles?",
      timestamp: new Date(Date.now() - 300000),
    },
    channel: "whatsapp",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: true,
    priority: "high",
    tags: ["interesado", "piso-goya"],
    assignedAgent: "Ana García",
  },
  {
    id: "conv_002",
    client: { name: "Carlos Ruiz", phone: "+34 600 234 567" },
    messages: [
      {
        id: "msg4",
        sender: "client",
        content: "¿Tienen más propiedades similares?",
        timestamp: new Date(Date.now() - 900000),
      },
      {
        id: "msg5",
        sender: "ai",
        content: "Por supuesto, tenemos varias opciones similares. ¿Qué características son más importantes para ti?",
        timestamp: new Date(Date.now() - 840000),
      },
    ],
    lastMessage: {
      id: "msg5",
      sender: "ai",
      content: "Por supuesto, tenemos varias opciones similares. ¿Qué características son más importantes para ti?",
      timestamp: new Date(Date.now() - 840000),
    },
    channel: "web",
    aiEnabled: false,
    isHumanTakeover: true,
    hasUnreadMessages: false,
    priority: "medium",
    tags: ["buscando-similar"],
    assignedAgent: "Luis Martín",
  },
  {
    id: "conv_003",
    client: { name: "Ana Fernández", phone: "+34 600 345 678" },
    messages: [
      {
        id: "msg6",
        sender: "client",
        content: "Buenos días, me gustaría información sobre apartamentos de 2 habitaciones.",
        timestamp: new Date(Date.now() - 1200000),
      },
      {
        id: "msg7",
        sender: "ai",
        content: "¡Buenos días Ana! Tenemos excelentes opciones de apartamentos de 2 habitaciones. ¿En qué zona te interesa buscar?",
        timestamp: new Date(Date.now() - 1140000),
      },
      {
        id: "msg8",
        sender: "client",
        content: "Preferiblemente en zona sur, con buen transporte público.",
        timestamp: new Date(Date.now() - 1080000),
      },
    ],
    lastMessage: {
      id: "msg8",
      sender: "client",
      content: "Preferiblemente en zona sur, con buen transporte público.",
      timestamp: new Date(Date.now() - 1080000),
    },
    channel: "whatsapp",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: true,
    priority: "medium",
    tags: ["apartamento-2hab", "zona-sur"],
    assignedAgent: "Ana García",
  },
  {
    id: "conv_004",
    client: { name: "Roberto Silva", phone: "+34 600 456 789" },
    messages: [
      {
        id: "msg9",
        sender: "client",
        content: "Hola, vi su anuncio en Idealista sobre el ático en Malasaña.",
        timestamp: new Date(Date.now() - 1800000),
      },
      {
        id: "msg10",
        sender: "agent",
        content: "¡Hola Roberto! Sí, el ático está disponible. Es una propiedad única con terraza de 40m². ¿Te interesa visitarlo?",
        timestamp: new Date(Date.now() - 1740000),
      },
      {
        id: "msg11",
        sender: "client",
        content: "Me encantaría verlo. ¿Cuándo podríamos agendar la visita?",
        timestamp: new Date(Date.now() - 1680000),
      },
      {
        id: "msg12",
        sender: "agent",
        content: "Perfecto. Tengo disponibilidad mañana a las 16:00 o el viernes a las 11:00. ¿Cuál te viene mejor?",
        timestamp: new Date(Date.now() - 1620000),
      },
    ],
    lastMessage: {
      id: "msg12",
      sender: "agent",
      content: "Perfecto. Tengo disponibilidad mañana a las 16:00 o el viernes a las 11:00. ¿Cuál te viene mejor?",
      timestamp: new Date(Date.now() - 1620000),
    },
    channel: "web",
    aiEnabled: false,
    isHumanTakeover: true,
    hasUnreadMessages: false,
    priority: "high",
    tags: ["atico", "malasana", "visita-programada"],
    assignedAgent: "Carlos López",
  },
  {
    id: "conv_005",
    client: { name: "Laura Martínez", phone: "+34 600 567 890" },
    messages: [
      {
        id: "msg13",
        sender: "client",
        content: "Buenas tardes, estoy buscando un local comercial en zona céntrica.",
        timestamp: new Date(Date.now() - 2400000),
      },
      {
        id: "msg14",
        sender: "ai",
        content: "¡Buenas tardes Laura! Tenemos varios locales comerciales disponibles en zona céntrica. ¿Qué tipo de negocio vas a abrir?",
        timestamp: new Date(Date.now() - 2340000),
      },
      {
        id: "msg15",
        sender: "client",
        content: "Una cafetería. Necesito al menos 80m² y que tenga salida de humos.",
        timestamp: new Date(Date.now() - 2280000),
      },
    ],
    lastMessage: {
      id: "msg15",
      sender: "client",
      content: "Una cafetería. Necesito al menos 80m² y que tenga salida de humos.",
      timestamp: new Date(Date.now() - 2280000),
    },
    channel: "whatsapp",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: true,
    priority: "medium",
    tags: ["local-comercial", "cafeteria", "centro"],
    assignedAgent: "Ana García",
  },
  {
    id: "conv_006",
    client: { name: "Diego Herrera", phone: "+34 600 678 901" },
    messages: [
      {
        id: "msg16",
        sender: "client",
        content: "Hola, quiero vender mi piso. ¿Pueden ayudarme con la valoración?",
        timestamp: new Date(Date.now() - 3600000),
      },
      {
        id: "msg17",
        sender: "ai",
        content: "¡Por supuesto Diego! Estaremos encantados de ayudarte. ¿Podrías contarme un poco sobre tu propiedad? Ubicación, metros cuadrados, habitaciones...",
        timestamp: new Date(Date.now() - 3540000),
      },
      {
        id: "msg18",
        sender: "client",
        content: "Está en Chamberí, 95m², 3 habitaciones, 2 baños, exterior con balcón.",
        timestamp: new Date(Date.now() - 3480000),
      },
      {
        id: "msg19",
        sender: "ai",
        content: "Excelente ubicación. Basándome en el mercado actual, estaríamos hablando de un rango entre 450.000€ y 520.000€. ¿Te gustaría que un agente visite la propiedad para una valoración más precisa?",
        timestamp: new Date(Date.now() - 3420000),
      },
    ],
    lastMessage: {
      id: "msg19",
      sender: "ai",
      content: "Excelente ubicación. Basándome en el mercado actual, estaríamos hablando de un rango entre 450.000€ y 520.000€. ¿Te gustaría que un agente visite la propiedad para una valoración más precisa?",
      timestamp: new Date(Date.now() - 3420000),
    },
    channel: "web",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: false,
    priority: "high",
    tags: ["venta", "chamberi", "valoracion"],
    assignedAgent: "Luis Martín",
  },
  {
    id: "conv_007",
    client: { name: "Carmen Jiménez", phone: "+34 600 789 012" },
    messages: [
      {
        id: "msg20",
        sender: "client",
        content: "Buenos días, necesito alquilar un apartamento para estudiantes.",
        timestamp: new Date(Date.now() - 4800000),
      },
      {
        id: "msg21",
        sender: "agent",
        content: "Buenos días Carmen. Tenemos varias opciones para estudiantes. ¿En qué zona prefieres y cuál es tu presupuesto máximo?",
        timestamp: new Date(Date.now() - 4740000),
      },
      {
        id: "msg22",
        sender: "client",
        content: "Cerca de Ciudad Universitaria, máximo 800€/mes, amueblado.",
        timestamp: new Date(Date.now() - 4680000),
      },
    ],
    lastMessage: {
      id: "msg22",
      sender: "client",
      content: "Cerca de Ciudad Universitaria, máximo 800€/mes, amueblado.",
      timestamp: new Date(Date.now() - 4680000),
    },
    channel: "whatsapp",
    aiEnabled: false,
    isHumanTakeover: true,
    hasUnreadMessages: true,
    priority: "low",
    tags: ["alquiler", "estudiantes", "ciudad-universitaria"],
    assignedAgent: "Carlos López",
  },
  {
    id: "conv_008",
    client: { name: "Javier Moreno", phone: "+34 600 890 123" },
    messages: [
      {
        id: "msg23",
        sender: "client",
        content: "Hola, estoy interesado en invertir en propiedades. ¿Qué me recomiendan?",
        timestamp: new Date(Date.now() - 7200000),
      },
      {
        id: "msg24",
        sender: "ai",
        content: "¡Hola Javier! Es genial que estés considerando la inversión inmobiliaria. ¿Tienes alguna preferencia en cuanto a tipo de propiedad o zona?",
        timestamp: new Date(Date.now() - 7140000),
      },
      {
        id: "msg25",
        sender: "client",
        content: "Me interesan apartamentos pequeños para alquiler, zonas con buena rentabilidad.",
        timestamp: new Date(Date.now() - 7080000),
      },
      {
        id: "msg26",
        sender: "ai",
        content: "Perfecto. Las zonas universitarias y cerca del metro suelen tener buena rentabilidad. Tengo varias opciones que podrían interesarte. ¿Cuál es tu presupuesto de inversión?",
        timestamp: new Date(Date.now() - 7020000),
      },
    ],
    lastMessage: {
      id: "msg26",
      sender: "ai",
      content: "Perfecto. Las zonas universitarias y cerca del metro suelen tener buena rentabilidad. Tengo varias opciones que podrían interesarte. ¿Cuál es tu presupuesto de inversión?",
      timestamp: new Date(Date.now() - 7020000),
    },
    channel: "web",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: false,
    priority: "medium",
    tags: ["inversion", "rentabilidad", "apartamentos"],
    assignedAgent: "Ana García",
  },
  {
    id: "conv_009",
    client: { name: "Patricia Vega", phone: "+34 600 901 234" },
    messages: [
      {
        id: "msg27",
        sender: "client",
        content: "Buenas, me han hablado muy bien de ustedes. Busco casa unifamiliar con jardín.",
        timestamp: new Date(Date.now() - 10800000),
      },
      {
        id: "msg28",
        sender: "agent",
        content: "¡Muchas gracias Patricia! Nos alegra saber que nos recomiendan. ¿En qué zona te gustaría la casa y tienes algún presupuesto en mente?",
        timestamp: new Date(Date.now() - 10740000),
      },
      {
        id: "msg29",
        sender: "client",
        content: "Zona norte de Madrid, hasta 600.000€. Con al menos 3 habitaciones.",
        timestamp: new Date(Date.now() - 10680000),
      },
      {
        id: "msg30",
        sender: "agent",
        content: "Perfecto, tenemos varias opciones en esa zona y presupuesto. Te voy a enviar algunas propiedades que creo que te pueden interesar.",
        timestamp: new Date(Date.now() - 10620000),
      },
    ],
    lastMessage: {
      id: "msg30",
      sender: "agent",
      content: "Perfecto, tenemos varias opciones en esa zona y presupuesto. Te voy a enviar algunas propiedades que creo que te pueden interesar.",
      timestamp: new Date(Date.now() - 10620000),
    },
    channel: "whatsapp",
    aiEnabled: false,
    isHumanTakeover: true,
    hasUnreadMessages: false,
    priority: "high",
    tags: ["casa-unifamiliar", "jardin", "zona-norte"],
    assignedAgent: "Luis Martín",
  },
  {
    id: "conv_010",
    client: { name: "Miguel Ángel Torres", phone: "+34 600 012 345" },
    messages: [
      {
        id: "msg31",
        sender: "client",
        content: "Hola, soy extranjero y quiero comprar en España. ¿Qué documentos necesito?",
        timestamp: new Date(Date.now() - 14400000),
      },
      {
        id: "msg32",
        sender: "ai",
        content: "¡Hola Miguel Ángel! Como extranjero puedes comprar sin problemas en España. Necesitarás NIE, pasaporte, y justificante de ingresos. ¿De qué país eres?",
        timestamp: new Date(Date.now() - 14340000),
      },
      {
        id: "msg33",
        sender: "client",
        content: "Soy de México. ¿El proceso es muy complicado?",
        timestamp: new Date(Date.now() - 14280000),
      },
    ],
    lastMessage: {
      id: "msg33",
      sender: "client",
      content: "Soy de México. ¿El proceso es muy complicado?",
      timestamp: new Date(Date.now() - 14280000),
    },
    channel: "web",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: true,
    priority: "medium",
    tags: ["extranjero", "mexico", "documentacion"],
    assignedAgent: "Carlos López",
  },
  {
    id: "conv_011",
    client: { name: "Elena Castillo", phone: "+34 600 123 567" },
    messages: [
      {
        id: "msg34",
        sender: "client",
        content: "Necesito vender rápido mi piso por traslado laboral. ¿Pueden ayudarme?",
        timestamp: new Date(Date.now() - 18000000),
      },
      {
        id: "msg35",
        sender: "agent",
        content: "Por supuesto Elena, entendemos la urgencia. ¿Podrías contarme los detalles de tu propiedad para hacer una valoración rápida?",
        timestamp: new Date(Date.now() - 17940000),
      },
    ],
    lastMessage: {
      id: "msg35",
      sender: "agent",
      content: "Por supuesto Elena, entendemos la urgencia. ¿Podrías contarme los detalles de tu propiedad para hacer una valoración rápida?",
      timestamp: new Date(Date.now() - 17940000),
    },
    channel: "whatsapp",
    aiEnabled: false,
    isHumanTakeover: true,
    hasUnreadMessages: false,
    priority: "high",
    tags: ["venta-urgente", "traslado", "valoracion-rapida"],
    assignedAgent: "Ana García",
  },
  {
    id: "conv_012",
    client: { name: "Fernando Ruiz", phone: "+34 600 234 678" },
    messages: [
      {
        id: "msg36",
        sender: "client",
        content: "Buenos días, quiero información sobre el proceso de hipoteca.",
        timestamp: new Date(Date.now() - 21600000),
      },
      {
        id: "msg37",
        sender: "ai",
        content: "Buenos días Fernando. Te puedo ayudar con información general sobre hipotecas. ¿Ya tienes una propiedad en mente o estás en fase de búsqueda?",
        timestamp: new Date(Date.now() - 21540000),
      },
      {
        id: "msg38",
        sender: "client",
        content: "Estoy viendo un piso de 280.000€. Es mi primera compra.",
        timestamp: new Date(Date.now() - 21480000),
      },
    ],
    lastMessage: {
      id: "msg38",
      sender: "client",
      content: "Estoy viendo un piso de 280.000€. Es mi primera compra.",
      timestamp: new Date(Date.now() - 21480000),
    },
    channel: "web",
    aiEnabled: true,
    isHumanTakeover: false,
    hasUnreadMessages: true,
    priority: "medium",
    tags: ["hipoteca", "primera-compra", "280k"],
    assignedAgent: "Luis Martín",
  }
]

const initialReports: Report[] = [
  {
    id: "rep_001",
    name: "Informe de Conversión de Leads - Q2 2024",
    type: "lead_conversion",
    generatedDate: new Date("2024-07-01"),
    url: "#",
  },
  {
    id: "rep_002",
    name: "Rendimiento de Agentes - Julio 2024",
    type: "agent_performance",
    generatedDate: new Date("2024-08-01"),
    url: "#",
  },
]

// Definición de planes simplificada para desarrollo
const planTiers: Record<string, PlanTier> = {
  starter: {
    id: "starter",
    name: "Starter",
    basePrice: 550,
    description: "Perfecto para equipos pequeños que inician",
    features: [
      "1,000 conversaciones/mes",
      "Hasta 10 usuarios",
      "500 leads",
      "CRM básico con IA",
      "Soporte por email",
    ],
    limits: {
      conversations: 1000,
      voiceCalls: 0,
      users: 10,
      leads: 500,
      valuations: 0,
      documents: 0,
      storage: 5,
      apiCalls: 1000,
    },
  },
  professional: {
    id: "professional",
    name: "Professional",
    basePrice: 900,
    description: "Para equipos en crecimiento - Solo Conversaciones y Leads",
    features: [
      "5,000 conversaciones/mes",
      "Hasta 20 usuarios",
      "2,000 leads",
      "CRM avanzado con IA",
      "Soporte prioritario",
      "Integraciones avanzadas",
    ],
    limits: {
      conversations: 5000,
      voiceCalls: 0,
      users: 20,
      leads: 2000,
      valuations: 0,
      documents: 0,
      storage: 25,
      apiCalls: 10000,
    },
    popular: true,
  },
  enterprise: {
    id: "enterprise",
    name: "Enterprise",
    basePrice: 1400,
    description: "Solución completa para empresas grandes - Solo Conversaciones y Leads",
    features: [
      "10,000 conversaciones/mes",
      "Hasta 50 usuarios",
      "5,000 leads",
      "CRM completo con IA avanzada",
      "Soporte 24/7",
      "API completa",
      "Integraciones personalizadas",
    ],
    limits: {
      conversations: 10000,
      voiceCalls: 0,
      users: 50,
      leads: 5000,
      valuations: 0,
      documents: 0,
      storage: 100,
      apiCalls: 50000,
    },
  },
}

const currentUsage: UsageMetrics = {
  period: "monthly",
  conversations: 4892,
  voiceCalls: 0,
  valuations: 0,
  documents: 0,
  apiCalls: 12456,
  storage: 18.7,
}

const initialState: AppState = {
  user: null,
  company: {
    id: "comp_001",
    name: "Inmobiliaria Premium",
    plan: planTiers.professional,
    services: [
      {
        id: "conversations",
        name: "Chatbot Web/WhatsApp",
        tier: "5,000 conversaciones",
        price: 500,
        isActive: true,
        usage: 4892,
        limit: 5000,
        unit: "conversaciones",
      },
      {
        id: "leads",
        name: "CRM + IA Leads",
        tier: "20 usuarios / 2,000 leads",
        price: 400,
        isActive: true,
        usage: 1456,
        limit: 2000,
        unit: "leads",
      },
      {
        id: "voice",
        name: "Chatbot con Voz",
        tier: "En desarrollo",
        price: 500,
        isActive: false,
        usage: 0,
        limit: 1000,
        unit: "llamadas",
      },
      {
        id: "valuations",
        name: "Valoración AVM",
        tier: "En desarrollo",
        price: 200,
        isActive: false,
        usage: 0,
        limit: 100,
        unit: "valoraciones",
      },
      {
        id: "documents",
        name: "Docs + Firma Digital",
        tier: "En desarrollo",
        price: 300,
        isActive: false,
        usage: 0,
        limit: 50,
        unit: "documentos",
      },
      {
        id: "analytics",
        name: "Analytics",
        tier: "Incluido",
        price: 0,
        isActive: true,
        usage: 0,
        limit: 0,
        unit: "",
      },
      {
        id: "reports",
        name: "Reportes",
        tier: "En desarrollo",
        price: 0,
        isActive: false,
        usage: 0,
        limit: 0,
        unit: "reportes",
      },
      {
        id: "billing",
        name: "Facturación",
        tier: "Incluido",
        price: 0,
        isActive: true,
        usage: 0,
        limit: 0,
        unit: "",
      },
      {
        id: "settings",
        name: "Configuración",
        tier: "Incluido",
        price: 0,
        isActive: true,
        usage: 0,
        limit: 0,
        unit: "",
      },
    ],
    usage: currentUsage,
    limits: planTiers.professional.limits,
    billing: {
      totalMonthly: 900, // Solo servicios activos
      nextBillingDate: new Date("2024-09-01"),
      paymentMethod: {
        brand: "Visa",
        last4: "4242",
        expiryMonth: "12",
        expiryYear: "2025",
      },
      stripeCustomerId: "cus_12345",
      stripeSubscriptionId: "sub_12345",
      usage: currentUsage,
    },
  },
  isAuthenticated: false,
  activeService: "dashboard",
  conversations: initialConversations,
  selectedConversation: null,
  leads: [
    {
      id: "lead_001",
      name: "María González",
      phone: "+34 600 123 456",
      email: "maria@email.com",
      status: "qualified",
      score: 8.5,
      source: "WhatsApp Bot",
      propertyInterest: "Apartamento 3 hab",
      budget: "300.000€ - 350.000€",
      lastActivity: new Date(Date.now() - 300000),
      createdAt: new Date(Date.now() - 86400000 * 5),
      assignedTo: "Ana García",
      notes: ["Interesada en zona centro", "Presupuesto confirmado", "Disponible fines de semana"],
      properties: [
        {
          id: "prop_interest_1",
          type: "apartment",
          location: "Centro Madrid",
          budget: { min: 300000, max: 350000 },
        },
      ],
    },
    {
      id: "lead_002",
      name: "Carlos Ruiz",
      phone: "+34 600 234 567",
      email: "carlos.ruiz@email.com",
      status: "contacted",
      score: 7.2,
      source: "Web Chat",
      propertyInterest: "Casa con jardín",
      budget: "450.000€ - 500.000€",
      lastActivity: new Date(Date.now() - 600000),
      createdAt: new Date(Date.now() - 86400000 * 3),
      assignedTo: "Luis Martín",
      notes: ["Busca casa unifamiliar", "Zona residencial preferida"],
      properties: [
        {
          id: "prop_interest_2",
          type: "house",
          location: "Zona Norte",
          budget: { min: 450000, max: 500000 },
        },
      ],
    },
    {
      id: "lead_003",
      name: "Ana Fernández",
      phone: "+34 600 345 678",
      email: "ana.fernandez@email.com",
      status: "new",
      score: 6.8,
      source: "Formulario Web",
      propertyInterest: "Apartamento 2 hab",
      budget: "250.000€ - 300.000€",
      lastActivity: new Date(Date.now() - 1800000),
      createdAt: new Date(Date.now() - 86400000 * 1),
      notes: ["Primera vivienda", "Financiación pendiente"],
      properties: [
        {
          id: "prop_interest_3",
          type: "apartment",
          location: "Zona Sur",
          budget: { min: 250000, max: 300000 },
        },
      ],
    },
    {
      id: "lead_004",
      name: "Roberto Silva",
      phone: "+34 600 456 789",
      email: "roberto.silva@email.com",
      status: "proposal",
      score: 9.1,
      source: "Web Chat",
      propertyInterest: "Ático con terraza",
      budget: "500.000€ - 600.000€",
      lastActivity: new Date(Date.now() - 1620000),
      createdAt: new Date(Date.now() - 86400000 * 2),
      assignedTo: "Carlos López",
      notes: ["Muy interesado en Malasaña", "Visita programada", "Presupuesto alto"],
      properties: [
        {
          id: "prop_interest_4",
          type: "apartment",
          location: "Malasaña",
          budget: { min: 500000, max: 600000 },
        },
      ],
    },
    {
      id: "lead_005",
      name: "Laura Martínez",
      phone: "+34 600 567 890",
      email: "laura.martinez@email.com",
      status: "new",
      score: 7.8,
      source: "WhatsApp Bot",
      propertyInterest: "Local comercial",
      budget: "150.000€ - 200.000€",
      lastActivity: new Date(Date.now() - 2280000),
      createdAt: new Date(Date.now() - 86400000 * 1),
      assignedTo: "Ana García",
      notes: ["Quiere abrir cafetería", "Necesita salida de humos", "Zona céntrica"],
      properties: [
        {
          id: "prop_interest_5",
          type: "commercial",
          location: "Centro Madrid",
          budget: { min: 150000, max: 200000 },
        },
      ],
    },
    {
      id: "lead_006",
      name: "Diego Herrera",
      phone: "+34 600 678 901",
      email: "diego.herrera@email.com",
      status: "qualified",
      score: 8.7,
      source: "Web Chat",
      propertyInterest: "Venta de piso",
      budget: "450.000€ - 520.000€",
      lastActivity: new Date(Date.now() - 3420000),
      createdAt: new Date(Date.now() - 86400000 * 2),
      assignedTo: "Luis Martín",
      notes: ["Quiere vender en Chamberí", "Valoración solicitada", "Propiedad en buen estado"],
      properties: [
        {
          id: "prop_interest_6",
          type: "apartment",
          location: "Chamberí",
          budget: { min: 450000, max: 520000 },
        },
      ],
    },
  ],
  properties: [
    {
      id: "prop_001",
      address: "Calle Mayor 123, Madrid",
      type: "apartment",
      value: 245000,
      confidence: 92,
      status: "completed",
      requestDate: new Date(Date.now() - 86400000),
    },
    {
      id: "prop_002",
      address: "Avenida de la Paz 45, Barcelona",
      type: "house",
      value: 380000,
      confidence: 88,
      status: "completed",
      requestDate: new Date(Date.now() - 86400000 * 2),
    },
    {
      id: "prop_003",
      address: "Plaza España 12, Valencia",
      type: "apartment",
      value: 0,
      confidence: 0,
      status: "processing",
      requestDate: new Date(Date.now() - 3600000),
    },
  ],
  documents: [
    {
      id: "doc_001",
      name: "Contrato de Arras - María González",
      type: "contract",
      status: "pending",
      clientName: "María González",
      createdDate: new Date(Date.now() - 86400000),
    },
    {
      id: "doc_002",
      name: "NDA - Valoración Propiedad",
      type: "agreement",
      status: "signed",
      clientName: "Carlos Ruiz",
      createdDate: new Date(Date.now() - 86400000 * 2),
    },
    {
      id: "doc_003",
      name: "Informe de Valoración - Ana Fernández",
      type: "report",
      status: "draft",
      clientName: "Ana Fernández",
      createdDate: new Date(Date.now() - 3600000 * 6),
    },
  ],
  notifications: [
    {
      id: "notif_001",
      title: "Nueva conversación",
      message: "María González ha iniciado chat",
      timestamp: new Date(Date.now() - 300000),
      read: false,
      type: "info",
    },
    {
      id: "notif_002",
      title: "Lead calificado",
      message: "Ana Fernández ha sido calificada como lead",
      timestamp: new Date(Date.now() - 600000),
      read: false,
      type: "success",
    },
    {
      id: "notif_003",
      title: "Conversación sin respuesta",
      message: "Miguel Ángel Torres lleva 4 horas sin respuesta",
      timestamp: new Date(Date.now() - 900000),
      read: false,
      type: "warning",
    },
    {
      id: "notif_004",
      title: "Nuevo lead de inversión",
      message: "Javier Moreno interesado en propiedades de inversión",
      timestamp: new Date(Date.now() - 1200000),
      read: true,
      type: "success",
    },
  ],
  reports: initialReports,
  modules: [
    {
      id: "conversations",
      name: "Chatbot Web/WhatsApp",
      description: "Automatización de conversaciones",
      isActive: true,
    },
    {
      id: "leads",
      name: "CRM + IA Leads",
      description: "Gestión inteligente de leads",
      isActive: true,
    },
    {
      id: "valuations",
      name: "Valoración AVM",
      description: "Valoraciones automáticas de propiedades",
      isActive: false,
    },
    {
      id: "documents",
      name: "Automatización Documental",
      description: "Generación y firma de documentos",
      isActive: false,
    },
    {
      id: "voice",
      name: "Call Center IA",
      description: "Asistente de voz para llamadas",
      isActive: false,
    },
    {
      id: "analytics",
      name: "Analytics",
      description: "Análisis y métricas avanzadas",
      isActive: true,
    },
    {
      id: "reports",
      name: "Reportes",
      description: "Informes y reportes automáticos",
      isActive: false,
    },
  ],
  systemSettings: {
    globalAiEnabled: true,
    webhookUrl: "https://api.inmobiliaria.com/webhook",
    whatsappApiKey: "sk_test_123456789",
    supportEmail: "soporte@inmobiliaria.com",
    maintenanceMode: false,
    allowNewRegistrations: true,
    maxUsersPerCompany: 20,
    defaultPlan: "professional",
    systemNotifications: {
      enabled: true,
      channels: ["email", "push", "sms"],
    },
  },
}

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case "LOGIN":
      return {
        ...state,
        isAuthenticated: true,
        user: {
          id: "user_001",
          name: action.payload.name || "Agente Inmobiliario",
          email: action.payload.email,
          role: "Agente",
          company: "Inmobiliaria Premium",
          avatar: action.payload.avatar,
          provider: action.payload.provider || 'email',
        },
      }
    case "LOGOUT":
      return { ...state, isAuthenticated: false, user: null, activeService: "dashboard" }
    case "SET_ACTIVE_SERVICE":
      return { ...state, activeService: action.payload }
    case "ADD_SERVICE":
      if (!state.company) return state
      const newServices = state.company.services.map((s) =>
        s.id === action.payload.id ? { ...action.payload, isActive: true } : s,
      )
      const newTotal = newServices.filter((s) => s.isActive).reduce((acc, s) => acc + s.price, 0)
      return {
        ...state,
        company: {
          ...state.company,
          services: newServices,
          billing: { ...state.company.billing, totalMonthly: newTotal },
        },
      }
    case "SELECT_CONVERSATION":
      return { ...state, selectedConversation: action.payload }
    case "ADD_MESSAGE": {
      const { conversationId, message } = action.payload
      const newConversations = state.conversations.map((conv) => {
        if (conv.id === conversationId) {
          const updatedMessages = [...conv.messages, message]
          return { ...conv, messages: updatedMessages, lastMessage: message }
        }
        return conv
      })
      const newSelectedConversation =
        state.selectedConversation?.id === conversationId
          ? {
              ...state.selectedConversation,
              messages: [...state.selectedConversation.messages, message],
              lastMessage: message,
            }
          : state.selectedConversation
      return { ...state, conversations: newConversations, selectedConversation: newSelectedConversation }
    }
    case "TOGGLE_AI": {
      const { conversationId, enabled } = action.payload
      const newConversations = state.conversations.map((conv) =>
        conv.id === conversationId ? { ...conv, aiEnabled: enabled, isHumanTakeover: !enabled } : conv,
      )
      const newSelectedConversation =
        state.selectedConversation?.id === conversationId
          ? { ...state.selectedConversation, aiEnabled: enabled, isHumanTakeover: !enabled }
          : state.selectedConversation
      return { ...state, conversations: newConversations, selectedConversation: newSelectedConversation }
    }
    case "TOGGLE_MODULE": {
      const { moduleId, enabled } = action.payload
      const newModules = state.modules.map((module) =>
        module.id === moduleId ? { ...module, isActive: enabled } : module,
      )
      return { ...state, modules: newModules }
    }
    case "SET_SYSTEM_SETTINGS":
      return { ...state, systemSettings: action.payload }
    case "UPGRADE_PLAN": {
      const { planId, services } = action.payload
      if (!state.company) return state

      const newPlan = planTiers[planId]
      if (!newPlan) return state

      const newTotal = services.filter((s) => s.isActive).reduce((acc, s) => acc + s.price, 0)

      return {
        ...state,
        company: {
          ...state.company,
          plan: newPlan,
          services: services,
          limits: newPlan.limits,
          billing: {
            ...state.company.billing,
            totalMonthly: newTotal,
          },
        },
      }
    }
    default:
      return state
  }
}

const AppContext = createContext<{
  state: AppState
  dispatch: React.Dispatch<AppAction>
  planTiers: Record<string, PlanTier>
} | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState)
  return <AppContext.Provider value={{ state, dispatch, planTiers }}>{children}</AppContext.Provider>
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within an AppProvider")
  }
  return context
}
