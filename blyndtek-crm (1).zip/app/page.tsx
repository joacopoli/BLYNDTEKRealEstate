import { AppProvider } from "@/lib/context/app-context"
import AppRouter from "@/components/app-router"

export default function Home() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  )
}
