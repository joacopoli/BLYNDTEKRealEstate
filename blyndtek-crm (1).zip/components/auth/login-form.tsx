"use client"

import type React from "react"
import { useState } from "react"
import { useApp } from "@/lib/context/app-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, EyeOff, Mail, Lock, Shield, Zap, Users, BarChart3 } from 'lucide-react'
import Image from "next/image"

export default function LoginForm() {
  const { dispatch } = useApp()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setLoading(true)
      setTimeout(() => {
        dispatch({ 
          type: "LOGIN", 
          payload: { 
            email, 
            name: "Agente Inmobiliario",
            provider: 'email'
          } 
        })
        setLoading(false)
      }, 1500)
    }
  }

  const handleGoogleLogin = () => {
    setLoading(true)
    // Simular login con Google
    setTimeout(() => {
      dispatch({ 
        type: "LOGIN", 
        payload: { 
          email: "usuario@gmail.com",
          name: "Usuario Google",
          avatar: "https://lh3.googleusercontent.com/a/default-user=s96-c",
          provider: 'google'
        } 
      })
      setLoading(false)
    }, 2000)
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(168,85,247,0.1),transparent_50%)]"></div>
        <div className="absolute top-20 left-20 w-96 h-96 bg-violet-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-indigo-200 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>

      {/* Floating Elements - Only Conversations & Leads */}
      <div className="absolute inset-0 opacity-8">
        <div className="absolute top-32 left-16 enterprise-card w-80 h-48 p-6 transform rotate-2 animate-fade-in">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-violet-100 rounded-lg">
              <Users className="w-6 h-6 text-violet-600" />
            </div>
            <div>
              <div className="h-3 bg-gray-200 rounded w-32 mb-2"></div>
              <div className="h-2 bg-gray-100 rounded w-24"></div>
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-2 bg-gray-200 rounded w-full"></div>
            <div className="h-2 bg-gray-200 rounded w-3/4"></div>
            <div className="h-2 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>

        <div className="absolute top-48 right-24 enterprise-card w-72 h-40 p-6 transform -rotate-1 animate-fade-in animation-delay-1000">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-violet-100 rounded-lg">
              <BarChart3 className="w-6 h-6 text-violet-600" />
            </div>
            <div>
              <div className="h-3 bg-gray-200 rounded w-28 mb-2"></div>
              <div className="h-2 bg-gray-100 rounded w-20"></div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="h-8 bg-gray-100 rounded"></div>
            <div className="h-8 bg-gray-100 rounded"></div>
            <div className="h-8 bg-gray-100 rounded"></div>
          </div>
        </div>

        <div className="absolute bottom-32 left-24 enterprise-card w-64 h-36 p-6 transform rotate-1 animate-fade-in animation-delay-2000">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-violet-100 rounded-lg">
              <Shield className="w-6 h-6 text-violet-600" />
            </div>
            <div>
              <div className="h-3 bg-gray-200 rounded w-24 mb-2"></div>
              <div className="h-2 bg-gray-100 rounded w-16"></div>
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-2 bg-gray-200 rounded w-full"></div>
            <div className="h-2 bg-gray-200 rounded w-2/3"></div>
          </div>
        </div>

        <div className="absolute bottom-24 right-32 enterprise-card w-68 h-44 p-6 transform -rotate-2 animate-fade-in animation-delay-3000">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-violet-100 rounded-lg">
              <Zap className="w-6 h-6 text-violet-600" />
            </div>
            <div>
              <div className="h-3 bg-gray-200 rounded w-20 mb-2"></div>
              <div className="h-2 bg-gray-100 rounded w-16"></div>
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-16 bg-gray-100 rounded"></div>
            <div className="h-2 bg-gray-200 rounded w-3/4"></div>
          </div>
        </div>
      </div>

      {/* Main Login Card */}
      <Card className="w-full max-w-sm relative z-10 enterprise-card bg-white/95 backdrop-blur-sm border-0">
        <CardHeader className="text-center">
          <Image
            src="/images/blyndtek-logo.png"
            alt="Blyndtek"
            width={140}
            height={40}
            className="mx-auto mb-4 h-8 w-auto"
          />
          <CardTitle>Bienvenido a Blyndtek</CardTitle>
          <CardDescription>Inicia sesión para acceder a tu CRM inmobiliario.</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Google Login Button */}
          <Button
            type="button"
            variant="outline"
            className="w-full h-12 text-base border-gray-300 hover:bg-gray-50"
            onClick={handleGoogleLogin}
            disabled={loading}
          >
            {loading ? (
              <div className="flex items-center">
                <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin mr-2"></div>
                Conectando con Google...
              </div>
            ) : (
              <div className="flex items-center">
                <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continuar con Google
              </div>
            )}
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-gray-500">O continúa con email</span>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-12 enterprise-input text-base"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Ingresa tu contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-12 h-12 enterprise-input text-base"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full h-12 enterprise-button text-base"
              disabled={!email || !password || loading}
            >
              {loading ? (
                <div className="flex items-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Verificando acceso...
                </div>
              ) : (
                "Iniciar Sesión"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Security Footer */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 text-center">
        <div className="flex items-center justify-center space-x-4 text-sm text-gray-500 mb-2">
          <div className="flex items-center space-x-1">
            <Shield className="w-4 h-4" />
            <span>Cifrado SSL</span>
          </div>
          <div className="w-1 h-1 bg-gray-300 rounded-full"></div>
          <div className="flex items-center space-x-1">
            <Lock className="w-4 h-4" />
            <span>Autenticación Segura</span>
          </div>
        </div>
        <p className="text-xs text-gray-400">© 2024 Blyndtek. CRM Inmobiliario Especializado</p>
      </div>
    </div>
  )
}
