"use client"

import type React from "react"

import { useApp } from "@/lib/context/app-context"
import Sidebar from "./layout/sidebar"
import Header from "./layout/header"
import DashboardOverview from "./dashboard/dashboard-overview"
import ConversationsPanel from "./services/conversations-panel"
import LeadsPanel from "./services/leads-panel"
import ValuationsPanel from "./services/valuations-panel"
import DocumentsPanel from "./services/documents-panel"
import VoicePanel from "./services/voice-panel"
import LockedServicePanel from "./services/locked-service-panel"
import ReportsPanel from "./services/reports-panel"
import BillingPanel from "./services/billing-panel"
import SettingsPanel from "./settings/settings-panel"

export default function MainApp() {
  const { state } = useApp()
  const { activeService, company } = state

  const isServiceActive = (serviceId: string) => {
    if (serviceId === "dashboard" || serviceId === "billing" || serviceId === "settings") return true
    return company?.services.find((s) => s.id === serviceId)?.isActive ?? false
  }

  const renderContent = () => {
    if (!isServiceActive(activeService)) {
      const service = company?.services.find((s) => s.id === activeService)
      return <LockedServicePanel service={service} />
    }

    switch (activeService) {
      case "dashboard":
        return <DashboardOverview />
      case "conversations":
        return <ConversationsPanel />
      case "leads":
        return <LeadsPanel />
      case "valuations":
        return <ValuationsPanel />
      case "documents":
        return <DocumentsPanel />
      case "voice":
        return <VoicePanel />
      case "reports":
        return <ReportsPanel />
      case "billing":
        return <BillingPanel />
      case "settings":
        return <SettingsPanel />
      default:
        return <DashboardOverview />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <Header />
        <main className="flex-1 overflow-y-auto" style={{ "--header-height": "4rem" } as React.CSSProperties}>
          {renderContent()}
        </main>
      </div>
    </div>
  )
}
