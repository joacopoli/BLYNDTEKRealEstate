"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, Bot, MessageSquare, Users } from 'lucide-react'
import type { ServiceId } from "@/lib/types"

export default function DashboardOverview() {
  const { state, dispatch } = useApp()
  const { company, conversations, leads } = state
  if (!company) return null

  const handleNavigation = (serviceId: ServiceId) => {
    dispatch({ type: "SET_ACTIVE_SERVICE", payload: serviceId })
  }

  const metrics = [
    {
      title: "Conversaciones Activas",
      value: conversations.length,
      icon: MessageSquare,
      serviceId: "conversations",
      description: "Gestionadas por IA",
    },
    {
      title: "Leads Cualificados",
      value: leads.filter((l) => l.status === "qualified").length,
      icon: Users,
      serviceId: "leads",
      description: "Listos para contactar",
    },
  ]

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-full">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-gray-500">Bienvenido, {state.user?.name || "Agente"}</p>
        </div>
      </div>

      <Card className="bg-gradient-to-r from-violet-600 to-purple-600 text-white shadow-lg rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3 text-xl">
            <Bot className="w-7 h-7" />
            <span>Tu Asistente IA está trabajando</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-violet-100 mb-6">Enfócate en cerrar ventas mientras la IA gestiona conversaciones y leads.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-3xl font-bold">98%</p>
              <p className="text-sm opacity-80">Automático</p>
            </div>
            <div>
              <p className="text-3xl font-bold">2.1s</p>
              <p className="text-sm opacity-80">Respuesta</p>
            </div>
            <div>
              <p className="text-3xl font-bold">24/7</p>
              <p className="text-sm opacity-80">Disponibilidad</p>
            </div>
            <div>
              <p className="text-3xl font-bold">4.9/5</p>
              <p className="text-sm opacity-80">Satisfacción</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {metrics.map((metric) => (
          <Card key={metric.title} className="bg-white shadow-sm hover:shadow-lg transition-shadow rounded-xl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium text-gray-600">{metric.title}</CardTitle>
                <metric.icon className="w-5 h-5 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-gray-900 mb-1">{metric.value}</p>
              <p className="text-xs text-gray-500 h-8">{metric.description}</p>
              <Button
                variant="outline"
                size="sm"
                className="w-full mt-4 bg-transparent"
                onClick={() => handleNavigation(metric.serviceId as ServiceId)}
              >
                Ir al módulo <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Development Notice */}
      <Card className="bg-amber-50 border-amber-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse"></div>
            <div>
              <p className="text-sm font-medium text-amber-800">Versión de Desarrollo</p>
              <p className="text-xs text-amber-600">
                Actualmente disponibles: Conversaciones y Gestión de Leads. 
                Próximamente: Valoraciones AVM, Documentos y más módulos.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
