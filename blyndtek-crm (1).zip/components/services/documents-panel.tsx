"use client"

import { useState } from "react"
import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import LockedServicePanel from "./locked-service-panel"
import { FileText, Plus, Download, Send, Eye, Edit, CheckCircle, Clock, AlertCircle, PenTool, Upload, Search } from 'lucide-react'

export default function DocumentsPanel() {
  const { state } = useApp()
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [selectedClient, setSelectedClient] = useState("")

  const documentMetrics = {
    totalDocuments: 47,
    pendingSignature: 12,
    signed: 28,
    drafts: 7,
    avgSigningTime: "2.3 días",
  }

  const documents = [
    {
      id: "doc_001",
      name: "Contrato de Arras - María González",
      type: "Contrato de Arras",
      client: "María González",
      status: "pending" as const,
      createdDate: new Date(Date.now() - 86400000),
      signedDate: null,
      progress: 75,
      signers: [
        { name: "María González", signed: true, signedAt: new Date(Date.now() - 3600000) },
        { name: "Inmobiliaria Premium", signed: false, signedAt: null },
      ],
    },
    {
      id: "doc_002",
      name: "Nota de Encargo - Carlos Ruiz",
      type: "Nota de Encargo",
      client: "Carlos Ruiz",
      status: "signed" as const,
      createdDate: new Date(Date.now() - 172800000),
      signedDate: new Date(Date.now() - 86400000),
      progress: 100,
      signers: [
        { name: "Carlos Ruiz", signed: true, signedAt: new Date(Date.now() - 90000000) },
        { name: "Inmobiliaria Premium", signed: true, signedAt: new Date(Date.now() - 86400000) },
      ],
    },
    {
      id: "doc_003",
      name: "Contrato de Alquiler - Ana Martín",
      type: "Contrato de Alquiler",
      client: "Ana Martín",
      status: "draft" as const,
      createdDate: new Date(Date.now() - 3600000),
      signedDate: null,
      progress: 25,
      signers: [],
    },
  ]

  const templates = [
    {
      id: "tpl_001",
      name: "Contrato de Arras",
      description: "Para reservar una propiedad con señal",
      fields: ["Datos del comprador", "Datos de la propiedad", "Importe de la señal", "Fecha de firma definitiva"],
    },
    {
      id: "tpl_002",
      name: "Nota de Encargo de Venta",
      description: "Autorización para comercializar una propiedad",
      fields: ["Datos del propietario", "Descripción de la propiedad", "Precio de venta", "Comisión"],
    },
    {
      id: "tpl_003",
      name: "Contrato de Alquiler",
      description: "Contrato de arrendamiento de vivienda",
      fields: ["Datos del inquilino", "Datos del propietario", "Renta mensual", "Duración del contrato"],
    },
    {
      id: "tpl_004",
      name: "Contrato de Compraventa",
      description: "Contrato definitivo de compraventa",
      fields: ["Datos del comprador", "Datos del vendedor", "Precio final", "Condiciones especiales"],
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "draft":
        return <Edit className="w-4 h-4 text-yellow-600" />
      case "pending":
        return <Clock className="w-4 h-4 text-blue-600" />
      case "signed":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      default:
        return <FileText className="w-4 h-4 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "draft":
        return "bg-yellow-100 text-yellow-800"
      case "pending":
        return "bg-blue-100 text-blue-800"
      case "signed":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "draft":
        return "Borrador"
      case "pending":
        return "Pendiente Firma"
      case "signed":
        return "Firmado"
      default:
        return "Desconocido"
    }
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-full">
      {/* Header */}
      <LockedServicePanel
        serviceName="Automatización de Documentos"
        description="Generación automática y firma digital de contratos y documentos"
        estimatedDate="Q2 2024"
      />

      {/* Métricas */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="p-4">
          <div className="flex items-center space-x-2 mb-2">
            <FileText className="w-4 h-4 text-violet-600" />
            <span className="text-sm font-medium text-gray-600">Total</span>
          </div>
          <div className="text-2xl font-bold text-violet-600">{documentMetrics.totalDocuments}</div>
          <div className="text-xs text-green-600 mt-1">+8 este mes</div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-600">Pendientes</span>
          </div>
          <div className="text-2xl font-bold text-blue-600">{documentMetrics.pendingSignature}</div>
          <div className="text-xs text-blue-600 mt-1">Esperando firma</div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center space-x-2 mb-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-gray-600">Firmados</span>
          </div>
          <div className="text-2xl font-bold text-green-600">{documentMetrics.signed}</div>
          <div className="text-xs text-green-600 mt-1">Completados</div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Edit className="w-4 h-4 text-yellow-600" />
            <span className="text-sm font-medium text-gray-600">Borradores</span>
          </div>
          <div className="text-2xl font-bold text-yellow-600">{documentMetrics.drafts}</div>
          <div className="text-xs text-yellow-600 mt-1">En edición</div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center space-x-2 mb-2">
            <PenTool className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-gray-600">Tiempo Firma</span>
          </div>
          <div className="text-2xl font-bold text-purple-600">{documentMetrics.avgSigningTime}</div>
          <div className="text-xs text-purple-600 mt-1">Promedio</div>
        </Card>
      </div>

      {/* Contenido principal */}
      <Tabs defaultValue="documents" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="documents">Documentos</TabsTrigger>
          <TabsTrigger value="create">Crear Documento</TabsTrigger>
          <TabsTrigger value="templates">Plantillas</TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Documentos Recientes</CardTitle>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input placeholder="Buscar documentos..." className="pl-10 w-64" />
                  </div>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {documents.map((doc) => (
                  <div key={doc.id} className="p-4 border rounded-lg bg-white">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(doc.status)}
                        <div>
                          <h3 className="font-medium text-gray-900">{doc.name}</h3>
                          <p className="text-sm text-gray-600">
                            {doc.type} • {doc.client}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Badge className={getStatusColor(doc.status)}>{getStatusText(doc.status)}</Badge>

                        <div className="flex items-center space-x-1">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="w-4 h-4" />
                          </Button>
                          {doc.status === "pending" && (
                            <Button variant="ghost" size="sm">
                              <Send className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>

                    {doc.status === "pending" && (
                      <div className="mb-3">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-gray-600">Progreso de firma</span>
                          <span className="font-medium">{doc.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${doc.progress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div>
                        Creado: {doc.createdDate.toLocaleDateString()}
                        {doc.signedDate && <span> • Firmado: {doc.signedDate.toLocaleDateString()}</span>}
                      </div>

                      {doc.signers.length > 0 && (
                        <div className="flex items-center space-x-2">
                          <span>Firmantes:</span>
                          {doc.signers.map((signer, index) => (
                            <div key={index} className="flex items-center space-x-1">
                              {signer.signed ? (
                                <CheckCircle className="w-3 h-3 text-green-600" />
                              ) : (
                                <Clock className="w-3 h-3 text-gray-400" />
                              )}
                              <span className="text-xs">{signer.name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="create" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Generar Nuevo Documento</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Seleccionar Plantilla</label>
                    <select
                      className="w-full mt-2 p-3 border border-gray-300 rounded-md bg-white"
                      value={selectedTemplate}
                      onChange={(e) => setSelectedTemplate(e.target.value)}
                    >
                      <option value="">Selecciona una plantilla...</option>
                      {templates.map((template) => (
                        <option key={template.id} value={template.id}>
                          {template.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700">Cliente</label>
                    <select
                      className="w-full mt-2 p-3 border border-gray-300 rounded-md bg-white"
                      value={selectedClient}
                      onChange={(e) => setSelectedClient(e.target.value)}
                    >
                      <option value="">Selecciona un cliente...</option>
                      <option value="maria">María González</option>
                      <option value="carlos">Carlos Ruiz</option>
                      <option value="ana">Ana Martín</option>
                    </select>
                  </div>

                  {selectedTemplate && (
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-medium text-blue-900 mb-2">Campos requeridos:</h4>
                      <div className="space-y-2">
                        {templates
                          .find((t) => t.id === selectedTemplate)
                          ?.fields.map((field, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <AlertCircle className="w-4 h-4 text-blue-600" />
                              <span className="text-sm text-blue-800">{field}</span>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center space-x-3">
                    <Button
                      className="bg-violet-600 hover:bg-violet-700"
                      disabled={!selectedTemplate || !selectedClient}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Generar Documento
                    </Button>
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Subir Documento
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Vista Previa</CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedTemplate ? (
                    <div className="space-y-3">
                      <div className="p-3 bg-gray-50 rounded border-2 border-dashed border-gray-300">
                        <div className="text-center text-gray-500">
                          <FileText className="w-8 h-8 mx-auto mb-2" />
                          <p className="text-sm">Vista previa del documento</p>
                          <p className="text-xs">{templates.find((t) => t.id === selectedTemplate)?.name}</p>
                        </div>
                      </div>
                      <p className="text-xs text-gray-600">
                        {templates.find((t) => t.id === selectedTemplate)?.description}
                      </p>
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-8">
                      <FileText className="w-8 h-8 mx-auto mb-2" />
                      <p className="text-sm">Selecciona una plantilla para ver la vista previa</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {templates.map((template) => (
              <Card key={template.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{template.description}</p>
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-gray-700">Campos incluidos:</h4>
                    {template.fields.map((field, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-violet-600 rounded-full" />
                        <span className="text-sm text-gray-600">{field}</span>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full mt-4 bg-violet-600 hover:bg-violet-700">Usar Plantilla</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
