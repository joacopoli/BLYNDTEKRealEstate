"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Clock, Zap, Calendar, ArrowRight } from 'lucide-react'

interface LockedServicePanelProps {
  serviceName: string
  description: string
  estimatedDate?: string
}

export default function LockedServicePanel({ 
  serviceName, 
  description, 
  estimatedDate = "Q2 2024" 
}: LockedServicePanelProps) {
  return (
    <div className="p-6 bg-gray-50 min-h-full flex items-center justify-center">
      <Card className="w-full max-w-2xl bg-white shadow-lg border-0">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mb-4">
            <Clock className="w-8 h-8 text-amber-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">
            {serviceName}
          </CardTitle>
          <p className="text-gray-500 mt-2">{description}</p>
        </CardHeader>
        
        <CardContent className="text-center space-y-6">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Zap className="w-5 h-5 text-amber-600" />
              <span className="font-semibold text-amber-800">En Desarrollo Activo</span>
            </div>
            <p className="text-sm text-amber-700">
              Nuestro equipo está trabajando intensamente en este módulo para ofrecerte 
              la mejor experiencia posible.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="bg-gray-50 rounded-lg p-4">
              <Calendar className="w-5 h-5 text-gray-600 mx-auto mb-2" />
              <p className="font-medium text-gray-800">Disponibilidad Estimada</p>
              <p className="text-gray-600">{estimatedDate}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <ArrowRight className="w-5 h-5 text-gray-600 mx-auto mb-2" />
              <p className="font-medium text-gray-800">Acceso Prioritario</p>
              <p className="text-gray-600">Usuarios actuales primero</p>
            </div>
          </div>

          <div className="pt-4">
            <p className="text-xs text-gray-500 mb-4">
              Mientras tanto, aprovecha al máximo los módulos de <strong>Conversaciones</strong> y <strong>Gestión de Leads</strong> 
              que están completamente funcionales.
            </p>
            
            <Button 
              variant="outline" 
              disabled 
              className="bg-gray-100 text-gray-400 cursor-not-allowed"
            >
              <Clock className="w-4 h-4 mr-2" />
              Próximamente Disponible
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
