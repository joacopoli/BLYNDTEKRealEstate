"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useApp } from "@/lib/context/app-context"
import { CreditCard, Download, TrendingUp, AlertTriangle, CheckCircle, Star, Zap, Users, MessageSquare, Phone, FileText, BarChart3, Settings, Crown, Sparkles, Home, DollarSign, Calendar, ArrowUp, Plus, Clock } from 'lucide-react'

const additionalServices = [
  {
    id: "voice-upgrade-5k",
    name: "Call Center IA - 5,000 llamadas",
    description: "Upgrade a 5,000 llamadas mensuales con panel omnicanal",
    price: 1500,
    currentPrice: 500,
    icon: <Phone className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "voice-upgrade-10k",
    name: "Call Center IA - 10,000 llamadas",
    description: "Máximo volumen de llamadas para empresas grandes",
    price: 3000,
    currentPrice: 500,
    icon: <Phone className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "conversations-upgrade-10k",
    name: "Chatbot - 10,000 conversaciones",
    description: "Upgrade a 10,000 conversaciones mensuales",
    price: 800,
    currentPrice: 500,
    icon: <MessageSquare className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "avm-upgrade-1k",
    name: "AVM - 1,000 valoraciones",
    description: "Upgrade a 1,000 valoraciones mensuales",
    price: 900,
    currentPrice: 200,
    icon: <Home className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "avm-upgrade-5k",
    name: "AVM - 5,000 valoraciones",
    description: "Máximo volumen de valoraciones",
    price: 2900,
    currentPrice: 200,
    icon: <Home className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "documents-upgrade-200",
    name: "Documentos - 200/mes",
    description: "Upgrade a 200 documentos mensuales",
    price: 600,
    currentPrice: 300,
    icon: <FileText className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "documents-upgrade-500",
    name: "Documentos - 500/mes",
    description: "Máximo volumen de documentos",
    price: 900,
    currentPrice: 300,
    icon: <FileText className="h-5 w-5" />,
    category: "upgrade",
  },
  {
    id: "premium-support",
    name: "Soporte Premium 24/7",
    description: "Soporte técnico dedicado con respuesta en menos de 1 hora",
    price: 200,
    icon: <Settings className="h-5 w-5" />,
    category: "addon",
  },
  {
    id: "custom-integrations",
    name: "Integraciones Personalizadas",
    description: "Desarrollo de integraciones específicas para tu negocio",
    price: 500,
    icon: <Zap className="h-5 w-5" />,
    category: "addon",
  },
  {
    id: "white-label",
    name: "Marca Blanca",
    description: "Personalización completa con tu marca y dominio",
    price: 800,
    icon: <Crown className="h-5 w-5" />,
    category: "addon",
  },
]

const invoiceHistory = [
  {
    id: "inv_001",
    date: "2024-08-01",
    amount: 1900,
    status: "paid",
    period: "Agosto 2024",
    services: ["Plan Professional", "Chatbot 5K", "CRM 20 usuarios", "AVM 100", "Documentos 50"],
  },
  {
    id: "inv_002",
    date: "2024-07-01",
    amount: 1900,
    status: "paid",
    period: "Julio 2024",
    services: ["Plan Professional", "Chatbot 5K", "CRM 20 usuarios", "AVM 100", "Documentos 50"],
  },
  {
    id: "inv_003",
    date: "2024-06-01",
    amount: 1600,
    status: "paid",
    period: "Junio 2024",
    services: ["Plan Professional", "Chatbot 5K", "CRM 20 usuarios", "AVM 100"],
  },
]

export default function BillingPanel() {
  const { state, planTiers } = useApp()
  const [selectedPlan, setSelectedPlan] = useState("professional")

  const company = state.company
  if (!company) return null

  const currentPlan = company.plan
  const currentServices = company.services.filter((s) => s.isActive)
  const totalMonthly = currentServices.reduce((acc, service) => acc + service.price, 0)
  const nextBilling = company.billing.nextBillingDate
  const usage = company.usage
  const limits = company.limits

  const getUsageColor = (usage: number, limit: number) => {
    if (limit === 0) return "text-green-600"
    const percentage = (usage / limit) * 100
    if (percentage >= 90) return "text-red-600"
    if (percentage >= 75) return "text-amber-600"
    return "text-green-600"
  }

  const getUsagePercentage = (usage: number, limit: number) => {
    if (limit === 0) return 0
    return Math.min((usage / limit) * 100, 100)
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-ES", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Facturación y Plan</h1>
          <p className="text-gray-500">Gestiona tu suscripción y métodos de pago</p>
        </div>
      </div>

      <Tabs defaultValue="current" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="current">Plan Actual</TabsTrigger>
          <TabsTrigger value="usage">Uso Detallado</TabsTrigger>
          <TabsTrigger value="plans">Cambiar Plan</TabsTrigger>
          <TabsTrigger value="history">Historial</TabsTrigger>
        </TabsList>

        {/* Plan Actual */}
        <TabsContent value="current" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Plan Overview */}
            <Card className="border-violet-200 bg-violet-50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Crown className="h-5 w-5 text-violet-600" />
                      Plan {currentPlan.name}
                    </CardTitle>
                    <CardDescription className="text-violet-700">{currentPlan.description}</CardDescription>
                  </div>
                  <Badge variant="secondary" className="bg-violet-100 text-violet-700">
                    {currentPlan.popular && <Star className="w-3 h-3 mr-1" />}
                    Activo
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-violet-600">{formatCurrency(totalMonthly)}/mes</div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Próxima facturación</span>
                    <span className="font-medium">
                      {nextBilling.toLocaleDateString("es-ES", {
                        day: "numeric",
                        month: "long",
                        year: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Método de pago</span>
                    <span className="font-medium">
                      {company.billing.paymentMethod.brand} ****{company.billing.paymentMethod.last4}
                    </span>
                  </div>
                </div>
                <Button className="w-full bg-transparent" variant="outline">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Actualizar Método de Pago
                </Button>
              </CardContent>
            </Card>

            {/* Servicios Activos */}
            <Card>
              <CardHeader>
                <CardTitle>Servicios Activos</CardTitle>
                <CardDescription>Módulos incluidos en tu plan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {currentServices.map((service) => (
                  <div key={service.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {service.id === "conversations" && <MessageSquare className="h-4 w-4 text-blue-600" />}
                      {service.id === "leads" && <Users className="h-4 w-4 text-green-600" />}
                      {service.id === "voice" && <Phone className="h-4 w-4 text-purple-600" />}
                      {service.id === "documents" && <FileText className="h-4 w-4 text-orange-600" />}
                      {service.id === "valuations" && <Home className="h-4 w-4 text-indigo-600" />}
                      {service.id === "reports" && <BarChart3 className="h-4 w-4 text-red-600" />}
                      {service.id === "analytics" && <TrendingUp className="h-4 w-4 text-emerald-600" />}
                      <div>
                        <div className="font-medium text-sm">{service.name}</div>
                        <div className="text-xs text-gray-500">{service.tier}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium text-sm">
                        {service.price > 0 ? formatCurrency(service.price) : "Incluido"}
                      </div>
                      {service.setupFee && (
                        <div className="text-xs text-gray-500">Setup: {formatCurrency(service.setupFee)}</div>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Servicios Adicionales y Upgrades */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-amber-500" />
                Upgrades y Servicios Adicionales
              </CardTitle>
              <CardDescription>Potencia tu plan con servicios premium y upgrades</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="upgrades" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="upgrades">Upgrades de Volumen</TabsTrigger>
                  <TabsTrigger value="addons">Servicios Adicionales</TabsTrigger>
                </TabsList>

                <TabsContent value="upgrades" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {additionalServices
                      .filter((service) => service.category === "upgrade")
                      .map((service) => (
                        <div key={service.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <div className="p-2 bg-violet-100 rounded-lg">{service.icon}</div>
                              <div className="flex-1">
                                <h4 className="font-medium">{service.name}</h4>
                                <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                                <div className="flex items-center justify-between mt-3">
                                  <div className="flex items-center gap-2">
                                    <span className="text-sm text-gray-500 line-through">
                                      {formatCurrency(service.currentPrice || 0)}
                                    </span>
                                    <ArrowUp className="h-3 w-3 text-gray-400" />
                                    <span className="font-bold text-violet-600">
                                      {formatCurrency(service.price)}/mes
                                    </span>
                                  </div>
                                  <Button size="sm" variant="outline">
                                    Upgrade
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="addons" className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    {additionalServices
                      .filter((service) => service.category === "addon")
                      .map((service) => (
                        <div key={service.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <div className="p-2 bg-violet-100 rounded-lg">{service.icon}</div>
                              <div className="flex-1">
                                <h4 className="font-medium">{service.name}</h4>
                                <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                                <div className="flex items-center justify-between mt-3">
                                  <span className="font-bold text-violet-600">{formatCurrency(service.price)}/mes</span>
                                  <Button size="sm" variant="outline">
                                    <Plus className="h-3 w-3 mr-1" />
                                    Agregar
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Uso Detallado */}
        <TabsContent value="usage" className="space-y-6">
          <div className="grid gap-6">
            {/* Métricas principales */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Conversaciones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold">{usage.conversations.toLocaleString()}</span>
                    <span className={`text-sm font-medium ${getUsageColor(usage.conversations, limits.conversations)}`}>
                      {getUsagePercentage(usage.conversations, limits.conversations).toFixed(0)}%
                    </span>
                  </div>
                  <Progress
                    value={getUsagePercentage(usage.conversations, limits.conversations)}
                    className="h-2 mb-2"
                  />
                  <p className="text-xs text-gray-500">de {limits.conversations.toLocaleString()} incluidas</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                    <Home className="w-4 h-4 mr-2" />
                    Valoraciones AVM
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold">{usage.valuations}</span>
                    <span className={`text-sm font-medium ${getUsageColor(usage.valuations, limits.valuations)}`}>
                      {getUsagePercentage(usage.valuations, limits.valuations).toFixed(0)}%
                    </span>
                  </div>
                  <Progress value={getUsagePercentage(usage.valuations, limits.valuations)} className="h-2 mb-2" />
                  <p className="text-xs text-gray-500">de {limits.valuations} incluidas</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                    <FileText className="w-4 h-4 mr-2" />
                    Documentos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold">{usage.documents}</span>
                    <span className={`text-sm font-medium ${getUsageColor(usage.documents, limits.documents)}`}>
                      {getUsagePercentage(usage.documents, limits.documents).toFixed(0)}%
                    </span>
                  </div>
                  <Progress value={getUsagePercentage(usage.documents, limits.documents)} className="h-2 mb-2" />
                  <p className="text-xs text-gray-500">de {limits.documents} incluidos</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                    <Phone className="w-4 h-4 mr-2" />
                    Llamadas de Voz
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold">{usage.voiceCalls}</span>
                    <span className="text-sm font-medium text-gray-500">No incluido</span>
                  </div>
                  <Progress value={0} className="h-2 mb-2" />
                  <p className="text-xs text-gray-500">Servicio no activo</p>
                </CardContent>
              </Card>
            </div>

            {/* Alertas de uso */}
            {getUsagePercentage(usage.conversations, limits.conversations) > 80 && (
              <Card className="border-amber-200 bg-amber-50">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span className="text-sm font-medium text-amber-900">Límite de conversaciones próximo</span>
                  </div>
                  <p className="text-sm text-amber-700">
                    Has usado el {getUsagePercentage(usage.conversations, limits.conversations).toFixed(0)}% de tus
                    conversaciones mensuales. Considera hacer un upgrade para evitar interrupciones.
                  </p>
                  <Button size="sm" className="mt-2 bg-amber-600 hover:bg-amber-700">
                    Ver Upgrades
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Desglose detallado */}
            <Card>
              <CardHeader>
                <CardTitle>Detalles de Uso Mensual</CardTitle>
                <CardDescription>Análisis detallado de tu consumo actual</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3">Uso por Servicio</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Chatbot Web/WhatsApp</span>
                          <span className="text-sm font-medium">
                            {usage.conversations.toLocaleString()} conversaciones
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Valoración AVM</span>
                          <span className="text-sm font-medium">{usage.valuations} valoraciones</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Automatización Documental</span>
                          <span className="text-sm font-medium">{usage.documents} documentos</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Llamadas API</span>
                          <span className="text-sm font-medium">{usage.apiCalls.toLocaleString()} llamadas</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">Límites del Plan</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Usuarios máximos</span>
                          <span className="text-sm font-medium">{limits.users} usuarios</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Leads máximos</span>
                          <span className="text-sm font-medium">{limits.leads.toLocaleString()} leads</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Almacenamiento</span>
                          <span className="text-sm font-medium">
                            {usage.storage} GB de {limits.storage} GB
                          </span>
                        </div>
                        <Progress value={getUsagePercentage(usage.storage, limits.storage)} className="h-2" />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Cambiar Plan */}
        <TabsContent value="plans" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-3">
            {Object.entries(planTiers).map(([key, plan]) => (
              <Card
                key={key}
                className={`relative ${selectedPlan === key ? "ring-2 ring-violet-500" : ""} ${
                  plan.popular ? "border-violet-200 scale-105" : ""
                } ${currentPlan.id === key ? "bg-violet-50 border-violet-300" : ""}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-violet-600 text-white">Más Popular</Badge>
                  </div>
                )}
                {currentPlan.id === key && (
                  <div className="absolute -top-3 right-4">
                    <Badge className="bg-green-600 text-white">Plan Actual</Badge>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-xl flex items-center justify-center gap-2">
                    {plan.name}
                    {plan.popular && <Star className="h-4 w-4 fill-current text-violet-600" />}
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-1">{plan.description}</p>
                  <div className="mt-4">
                    <span className="text-3xl font-bold">{formatCurrency(plan.basePrice)}</span>
                    <span className="text-gray-600">/mes</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-sm mb-2">Incluye:</h4>
                    <div className="space-y-1">
                      {plan.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <CheckCircle className="w-3 h-3 text-green-600" />
                          <span className="text-xs">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2">
                    <h4 className="font-medium text-sm mb-2">Límites:</h4>
                    <div className="grid grid-cols-2 gap-1 text-xs text-gray-600">
                      <div>{plan.limits.conversations.toLocaleString()} conversaciones</div>
                      <div>{plan.limits.users} usuarios</div>
                      <div>{plan.limits.leads.toLocaleString()} leads</div>
                      <div>{plan.limits.storage} GB storage</div>
                      {plan.limits.valuations > 0 && <div>{plan.limits.valuations} valoraciones</div>}
                      {plan.limits.documents > 0 && <div>{plan.limits.documents} documentos</div>}
                      {plan.limits.voiceCalls > 0 && <div>{plan.limits.voiceCalls} llamadas</div>}
                    </div>
                  </div>

                  <Button
                    className={`w-full ${
                      currentPlan.id === key
                        ? "bg-gray-400 cursor-not-allowed"
                        : plan.popular
                          ? "bg-violet-600 hover:bg-violet-700"
                          : "bg-gray-600 hover:bg-gray-700"
                    }`}
                    disabled={currentPlan.id === key}
                    onClick={() => setSelectedPlan(key)}
                  >
                    {currentPlan.id === key ? "Plan Actual" : "Seleccionar Plan"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Información adicional sobre cambios de plan */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Información sobre Cambios de Plan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Cambios inmediatos</p>
                  <p className="text-xs text-gray-600">Los upgrades se activan inmediatamente</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="h-4 w-4 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Facturación prorrateada</p>
                  <p className="text-xs text-gray-600">Solo pagas la diferencia hasta tu próximo ciclo</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Settings className="h-4 w-4 text-purple-600 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Configuración automática</p>
                  <p className="text-xs text-gray-600">Todos los servicios se configuran automáticamente</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Historial */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Historial de Facturas</CardTitle>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Descargar Todas
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {invoiceHistory.map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Factura #{invoice.id}</h3>
                        <p className="text-sm text-gray-600">{invoice.period}</p>
                        <div className="text-xs text-gray-500 mt-1">{invoice.services.join(" • ")}</div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="font-medium">{formatCurrency(invoice.amount)}</div>
                        <div className="text-sm text-gray-600">
                          {new Date(invoice.date).toLocaleDateString("es-ES")}
                        </div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Pagada</Badge>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-1" />
                        PDF
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Resumen anual */}
          <Card>
            <CardHeader>
              <CardTitle>Resumen Anual 2024</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-violet-600">$22,800</div>
                  <div className="text-sm text-gray-600">Total facturado</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">38,564</div>
                  <div className="text-sm text-gray-600">Conversaciones procesadas</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">804</div>
                  <div className="text-sm text-gray-600">Valoraciones realizadas</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">276</div>
                  <div className="text-sm text-gray-600">Documentos generados</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Development Notice */}
      <Card className="mt-6 bg-amber-50 border-amber-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <AlertCircle className="w-5 h-5 text-amber-600" />
            <div>
              <p className="text-sm font-medium text-amber-800">Versión de Desarrollo</p>
              <p className="text-xs text-amber-600">
                Actualmente solo se facturan los módulos de Conversaciones y Leads. 
                Los módulos adicionales se activarán gradualmente sin costo extra durante el período de desarrollo.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
