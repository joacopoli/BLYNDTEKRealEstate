"use client"

import { useState } from "react"
import { useApp } from "@/lib/context/app-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Search, Plus, MoreHorizontal } from 'lucide-react'

export default function LeadsPanel() {
  const { state } = useApp()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  const filteredLeads = state.leads.filter(lead => {
    const matchesSearch = lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         lead.phone.includes(searchTerm)
    const matchesStatus = statusFilter === "all" || lead.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    const colors = {
      new: "bg-blue-100 text-blue-800",
      contacted: "bg-yellow-100 text-yellow-800", 
      qualified: "bg-green-100 text-green-800",
      proposal: "bg-purple-100 text-purple-800",
      closed: "bg-emerald-100 text-emerald-800",
      lost: "bg-red-100 text-red-800"
    }
    
    const labels = {
      new: "Nuevo",
      contacted: "Contactado",
      qualified: "Cualificado", 
      proposal: "Propuesta",
      closed: "Cerrado",
      lost: "Perdido"
    }
    
    return (
      <Badge className={colors[status as keyof typeof colors] || colors.new}>
        {labels[status as keyof typeof labels] || status}
      </Badge>
    )
  }

  const stats = {
    total: state.leads.length,
    new: state.leads.filter(l => l.status === "new").length,
    qualified: state.leads.filter(l => l.status === "qualified").length,
    proposal: state.leads.filter(l => l.status === "proposal").length,
    closed: state.leads.filter(l => l.status === "closed").length
  }

  return (
    <div className="p-6 bg-gray-50 h-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Leads</h1>
          <p className="text-gray-500">Administra y convierte tus leads en clientes</p>
        </div>
        <Button className="bg-violet-600 hover:bg-violet-700">
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Lead
        </Button>
      </div>

      {/* Stats Cards - Simplificadas */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
            <p className="text-sm text-gray-600">Total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-gray-600">{stats.new}</p>
            <p className="text-sm text-gray-600">Nuevos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-green-600">{stats.qualified}</p>
            <p className="text-sm text-gray-600">Cualificados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-purple-600">{stats.proposal}</p>
            <p className="text-sm text-gray-600">Propuestas</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-emerald-600">{stats.closed}</p>
            <p className="text-sm text-gray-600">Cerrados</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros Simplificados */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar leads..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={statusFilter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setStatusFilter("all")}
              >
                Todos
              </Button>
              <Button
                variant={statusFilter === "new" ? "default" : "outline"}
                size="sm"
                onClick={() => setStatusFilter("new")}
              >
                Nuevos
              </Button>
              <Button
                variant={statusFilter === "qualified" ? "default" : "outline"}
                size="sm"
                onClick={() => setStatusFilter("qualified")}
              >
                Cualificados
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabla Simplificada */}
      <div className="bg-white rounded-xl shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Teléfono</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Interés</TableHead>
              <TableHead>Presupuesto</TableHead>
              <TableHead>Fuente</TableHead>
              <TableHead>Última Actividad</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLeads.map((lead) => (
              <TableRow key={lead.id}>
                <TableCell>
                  <div className="font-medium">{lead.name}</div>
                  {lead.assignedTo && (
                    <div className="text-xs text-gray-500">Asignado a: {lead.assignedTo}</div>
                  )}
                </TableCell>
                <TableCell className="text-sm">{lead.email}</TableCell>
                <TableCell className="text-sm">{lead.phone}</TableCell>
                <TableCell>
                  <span className="font-semibold">{lead.score}/10</span>
                </TableCell>
                <TableCell>
                  {getStatusBadge(lead.status)}
                </TableCell>
                <TableCell className="text-sm">{lead.propertyInterest}</TableCell>
                <TableCell className="text-sm font-medium">{lead.budget}</TableCell>
                <TableCell className="text-sm">{lead.source}</TableCell>
                <TableCell className="text-sm">
                  {lead.lastActivity.toLocaleDateString()}
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {filteredLeads.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm p-8 text-center mt-6">
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No se encontraron leads
          </h3>
          <p className="text-gray-500">
            {searchTerm ? 'Intenta con otros términos de búsqueda' : 'Los nuevos leads aparecerán aquí'}
          </p>
        </div>
      )}
    </div>
  )
}
