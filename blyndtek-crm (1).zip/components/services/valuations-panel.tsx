"use client"

import type React from "react"
import LockedServicePanel from "./locked-service-panel"

import { useState } from "react"
import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2 } from 'lucide-react'

export default function ValuationsPanel() {
  const { state } = useApp()
  const { properties } = state
  const [isProcessing, setIsProcessing] = useState(false)

  const handleGenerateValuation = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsProcessing(true)
    setTimeout(() => {
      setIsProcessing(false)
      // Aquí iría la lógica para añadir la nueva valoración al estado global
    }, 2000)
  }

  return (
    <LockedServicePanel
      serviceName="Valoraciones AVM"
      description="Sistema automático de valoración de propiedades con IA avanzada"
      estimatedDate="Q2 2024"
    >
      <div className="p-6 bg-gray-50 h-full grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Nueva Valoración AVM</CardTitle>
              <CardDescription>Introduce los datos para obtener una tasación automática.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleGenerateValuation} className="space-y-4">
                <div>
                  <Label htmlFor="address">Dirección</Label>
                  <Input id="address" placeholder="Ej: Calle Goya, 28, Madrid" required />
                </div>
                <div>
                  <Label htmlFor="type">Tipo de Propiedad</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="apartment">Apartamento</SelectItem>
                      <SelectItem value="house">Casa</SelectItem>
                      <SelectItem value="commercial">Local Comercial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="area">Superficie (m²)</Label>
                    <Input id="area" type="number" placeholder="120" required />
                  </div>
                  <div>
                    <Label htmlFor="rooms">Habitaciones</Label>
                    <Input id="rooms" type="number" placeholder="3" required />
                  </div>
                  <div>
                    <Label htmlFor="baths">Baños</Label>
                    <Input id="baths" type="number" placeholder="2" required />
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={isProcessing}>
                  {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {isProcessing ? "Procesando..." : "Generar Valoración"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Historial de Valoraciones</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Dirección</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Valor Estimado</TableHead>
                    <TableHead>Confianza</TableHead>
                    <TableHead>Fecha</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {properties.map((prop) => (
                    <TableRow key={prop.id}>
                      <TableCell className="font-medium">{prop.address}</TableCell>
                      <TableCell>{prop.type.charAt(0).toUpperCase() + prop.type.slice(1)}</TableCell>
                      <TableCell className="font-semibold">
                        {prop.value.toLocaleString("es-ES", { style: "currency", currency: "EUR" })}
                      </TableCell>
                      <TableCell>{prop.confidence}%</TableCell>
                      <TableCell>{prop.requestDate.toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </LockedServicePanel>
  )
}
