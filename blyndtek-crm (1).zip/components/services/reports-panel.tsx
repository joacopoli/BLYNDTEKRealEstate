"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Download } from 'lucide-react'
import LockedServicePanel from "./locked-service-panel"

export default function ReportsPanel() {
  const { state } = useApp()
  const { reports } = state

  return (
    <LockedServicePanel
      serviceName="Reportes y Analytics"
      description="Informes detallados y análisis avanzado de rendimiento"
      estimatedDate="Q2 2024"
    >
      <div className="p-6 bg-gray-50 h-full">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Reportes y Analítica</h1>
          <Button>Generar Nuevo Reporte</Button>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Historial de Reportes</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre del Reporte</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Fecha de Generación</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">{report.name}</TableCell>
                    <TableCell>{report.type}</TableCell>
                    <TableCell>{report.generatedDate.toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" asChild>
                        <a href={report.url} download>
                          <Download className="w-4 h-4 mr-2" />
                          Descargar
                        </a>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </LockedServicePanel>
  )
}
