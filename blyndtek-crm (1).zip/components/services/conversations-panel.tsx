"use client"

import { useState } from "react"
import { useApp } from "@/lib/context/app-context"
import ChatInterface from "@/components/chat/chat-interface"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Search, MessageCircle, Bot, User, Phone, Globe, Send, MoreVertical, AlertCircle, CheckCircle2, Clock } from 'lucide-react'
import { cn } from "@/lib/utils"

export default function ConversationsPanel() {
  const { state, dispatch } = useApp()

  return (
    <div className="h-full">
      <ChatInterface
        conversations={state.conversations}
        selectedConversation={state.selectedConversation}
        onSelectConversation={(conv) => dispatch({ type: "SELECT_CONVERSATION", payload: conv })}
        onSendMessage={(conversationId, message) =>
          dispatch({ type: "ADD_MESSAGE", payload: { conversationId, message } })
        }
        onToggleAi={(conversationId, enabled) => 
          dispatch({ type: "TOGGLE_AI", payload: { conversationId, enabled } })
        }
        currentUser={state.user}
      />
    </div>
  )
}
