"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Search,
  Filter,
  Plus,
  MoreVertical,
  Phone,
  Mail,
  Calendar,
  TrendingUp,
  Users,
  Target,
  Award,
} from "lucide-react"
import { useState } from "react"

export default function CRMLeadsPanel() {
  const { state } = useApp()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")

  const filteredLeads = state.leads.filter((lead) => {
    const matchesSearch =
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (lead.email && lead.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
      lead.phone.includes(searchTerm)
    const matchesStatus = selectedStatus === "all" || lead.status === selectedStatus
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "contacted":
        return "bg-yellow-100 text-yellow-800"
      case "qualified":
        return "bg-green-100 text-green-800"
      case "proposal":
        return "bg-purple-100 text-purple-800"
      case "closed-won":
        return "bg-emerald-100 text-emerald-800"
      case "closed-lost":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "new":
        return "Nuevo"
      case "contacted":
        return "Contactado"
      case "qualified":
        return "Cualificado"
      case "proposal":
        return "Propuesta"
      case "closed-won":
        return "Cerrado Ganado"
      case "closed-lost":
        return "Cerrado Perdido"
      default:
        return status
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 8) return "text-green-600"
    if (score >= 6) return "text-yellow-600"
    return "text-red-600"
  }

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const leadStats = {
    total: state.leads.length,
    new: state.leads.filter((l) => l.status === "new").length,
    qualified: state.leads.filter((l) => l.status === "qualified").length,
    avgScore: state.leads.reduce((acc, l) => acc + l.score, 0) / state.leads.length || 0,
  }

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Total Leads
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{leadStats.total}</div>
            <p className="text-xs text-green-600 mt-1">+12% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Target className="w-4 h-4 mr-2" />
              Nuevos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{leadStats.new}</div>
            <p className="text-xs text-blue-600 mt-1">Esta semana</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Award className="w-4 h-4 mr-2" />
              Cualificados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{leadStats.qualified}</div>
            <p className="text-xs text-green-600 mt-1">Listos para propuesta</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Score Promedio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{leadStats.avgScore.toFixed(1)}</div>
            <p className="text-xs text-gray-500 mt-1">Sobre 10 puntos</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Actions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Gestión de Leads</CardTitle>
            <Button className="bg-indigo-600 hover:bg-indigo-700">
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Lead
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar leads..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Estado: {selectedStatus === "all" ? "Todos" : getStatusLabel(selectedStatus)}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setSelectedStatus("all")}>Todos</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("new")}>Nuevos</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("contacted")}>Contactados</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("qualified")}>Cualificados</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSelectedStatus("proposal")}>En Propuesta</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Leads List */}
          <div className="space-y-4">
            {filteredLeads.map((lead) => (
              <div key={lead.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={`/placeholder.svg?height=48&width=48&text=${lead.name.charAt(0)}`} />
                      <AvatarFallback className="bg-indigo-100 text-indigo-600">{lead.name.charAt(0)}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-medium text-gray-900">{lead.name}</h3>
                        <Badge className={getStatusColor(lead.status)}>{getStatusLabel(lead.status)}</Badge>
                        <div className="flex items-center space-x-1">
                          <TrendingUp className={`w-4 h-4 ${getScoreColor(lead.score)}`} />
                          <span className={`text-sm font-medium ${getScoreColor(lead.score)}`}>{lead.score}/10</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                        {lead.email && (
                          <div className="flex items-center space-x-1">
                            <Mail className="w-4 h-4" />
                            <span>{lead.email}</span>
                          </div>
                        )}
                        <div className="flex items-center space-x-1">
                          <Phone className="w-4 h-4" />
                          <span>{lead.phone}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>Fuente: {lead.source}</span>
                        <span>•</span>
                        <span>Creado: {formatDate(lead.createdAt)}</span>
                        <span>•</span>
                        <span>Última actividad: {formatDate(lead.lastActivity)}</span>
                        {lead.assignedTo && (
                          <>
                            <span>•</span>
                            <span>Asignado a: {lead.assignedTo}</span>
                          </>
                        )}
                      </div>

                      {/* Property Interests */}
                      {lead.properties && lead.properties.length > 0 && (
                        <div className="mt-3">
                          <p className="text-sm font-medium text-gray-700 mb-1">Intereses:</p>
                          <div className="space-y-1">
                            {lead.properties.map((property) => (
                              <div key={property.id} className="text-sm text-gray-600">
                                <span className="font-medium capitalize">{property.type}</span> en {property.location}
                                <span className="text-gray-500">
                                  {" "}
                                  (€{property.budget.min.toLocaleString()} - €{property.budget.max.toLocaleString()})
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Notes */}
                      {lead.notes && lead.notes.length > 0 && (
                        <div className="mt-3">
                          <p className="text-sm font-medium text-gray-700 mb-1">Notas:</p>
                          <div className="space-y-1">
                            {lead.notes.slice(0, 2).map((note, index) => (
                              <p key={index} className="text-sm text-gray-600">
                                • {note}
                              </p>
                            ))}
                            {lead.notes.length > 2 && (
                              <p className="text-sm text-gray-500">+{lead.notes.length - 2} notas más</p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      <Phone className="w-4 h-4 mr-1" />
                      Llamar
                    </Button>
                    <Button variant="outline" size="sm">
                      <Mail className="w-4 h-4 mr-1" />
                      Email
                    </Button>
                    <Button variant="outline" size="sm">
                      <Calendar className="w-4 h-4 mr-1" />
                      Cita
                    </Button>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>Ver perfil completo</DropdownMenuItem>
                        <DropdownMenuItem>Editar información</DropdownMenuItem>
                        <DropdownMenuItem>Cambiar estado</DropdownMenuItem>
                        <DropdownMenuItem>Asignar agente</DropdownMenuItem>
                        <DropdownMenuItem>Agregar nota</DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">Eliminar lead</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            ))}

            {filteredLeads.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm ? "No se encontraron leads" : "No hay leads"}
                </h3>
                <p className="text-gray-500 mb-4">
                  {searchTerm
                    ? "Intenta con otros términos de búsqueda"
                    : "Los nuevos leads aparecerán aquí automáticamente"}
                </p>
                {!searchTerm && (
                  <Button className="bg-indigo-600 hover:bg-indigo-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Crear primer lead
                  </Button>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
