"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Users, MessageSquare, Home, Download, Filter, RefreshCw, Target, Clock } from "lucide-react"

export default function AnalyticsPanel() {
  const { state } = useApp()

  const overviewStats = {
    totalConversations: 1250,
    totalLeads: 156,
    totalValuations: 45,
    conversionRate: 23.5,
  }

  const monthlyData = [
    { month: "Ene", conversations: 980, leads: 120, valuations: 32 },
    { month: "Feb", conversations: 1100, leads: 140, valuations: 38 },
    { month: "Mar", conversations: 1250, leads: 156, valuations: 45 },
  ]

  const channelStats = [
    { channel: "WhatsApp", conversations: 812, percentage: 65, color: "bg-green-500" },
    { channel: "Web Chat", conversations: 438, percentage: 35, color: "bg-blue-500" },
  ]

  const leadSources = [
    { source: "WhatsApp Bot", leads: 89, percentage: 57, color: "bg-green-500" },
    { source: "Web Chat", leads: 45, percentage: 29, color: "bg-blue-500" },
    { source: "Referidos", leads: 22, percentage: 14, color: "bg-purple-500" },
  ]

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <MessageSquare className="w-4 h-4 mr-2" />
              Conversaciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{overviewStats.totalConversations}</div>
            <p className="text-xs text-green-600 mt-1">+12% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Leads Generados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{overviewStats.totalLeads}</div>
            <p className="text-xs text-blue-600 mt-1">+8% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Home className="w-4 h-4 mr-2" />
              Valoraciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{overviewStats.totalValuations}</div>
            <p className="text-xs text-indigo-600 mt-1">+15% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Target className="w-4 h-4 mr-2" />
              Tasa Conversión
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{overviewStats.conversionRate}%</div>
            <p className="text-xs text-green-600 mt-1">+2.1% vs mes anterior</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Analytics */}
      <Tabs defaultValue="overview" className="space-y-6">
        <div className="flex items-center justify-between">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="overview">General</TabsTrigger>
            <TabsTrigger value="conversations">Chat</TabsTrigger>
            <TabsTrigger value="leads">Leads</TabsTrigger>
            <TabsTrigger value="performance">Rendimiento</TabsTrigger>
          </TabsList>

          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              Filtros
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
            <Button variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Actualizar
            </Button>
          </div>
        </div>

        <TabsContent value="overview" className="space-y-6">
          {/* Monthly Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Tendencias Mensuales
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-sm text-gray-600">Conversaciones</p>
                    <div className="flex items-end justify-center space-x-1 h-20 mt-2">
                      {monthlyData.map((data, index) => (
                        <div key={index} className="flex flex-col items-center">
                          <div
                            className="w-8 bg-blue-500 rounded-t"
                            style={{ height: `${(data.conversations / 1250) * 60}px` }}
                          />
                          <span className="text-xs text-gray-500 mt-1">{data.month}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600">Leads</p>
                    <div className="flex items-end justify-center space-x-1 h-20 mt-2">
                      {monthlyData.map((data, index) => (
                        <div key={index} className="flex flex-col items-center">
                          <div
                            className="w-8 bg-green-500 rounded-t"
                            style={{ height: `${(data.leads / 156) * 60}px` }}
                          />
                          <span className="text-xs text-gray-500 mt-1">{data.month}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-600">Valoraciones</p>
                    <div className="flex items-end justify-center space-x-1 h-20 mt-2">
                      {monthlyData.map((data, index) => (
                        <div key={index} className="flex flex-col items-center">
                          <div
                            className="w-8 bg-purple-500 rounded-t"
                            style={{ height: `${(data.valuations / 45) * 60}px` }}
                          />
                          <span className="text-xs text-gray-500 mt-1">{data.month}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Channel Distribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Canal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {channelStats.map((channel) => (
                    <div key={channel.channel} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">{channel.channel}</span>
                        <span>
                          {channel.conversations} ({channel.percentage}%)
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`${channel.color} h-2 rounded-full`}
                          style={{ width: `${channel.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Fuentes de Leads</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {leadSources.map((source) => (
                    <div key={source.source} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">{source.source}</span>
                        <span>
                          {source.leads} ({source.percentage}%)
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`${source.color} h-2 rounded-full`}
                          style={{ width: `${source.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="conversations" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Tiempo Promedio de Respuesta</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">2.3s</div>
                <p className="text-sm text-green-600 mt-1">-0.5s vs mes anterior</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Satisfacción del Cliente</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-yellow-600">4.8/5</div>
                <p className="text-sm text-green-600 mt-1">+0.2 vs mes anterior</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Tasa de Resolución</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">78%</div>
                <p className="text-sm text-green-600 mt-1">+5% vs mes anterior</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Horarios de Mayor Actividad</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {["L", "M", "X", "J", "V", "S", "D"].map((day, index) => (
                  <div key={day} className="text-center">
                    <div className="text-xs text-gray-500 mb-2">{day}</div>
                    <div className="space-y-1">
                      {Array.from({ length: 24 }, (_, hour) => (
                        <div
                          key={hour}
                          className={`h-1 rounded ${
                            index < 5 && hour >= 9 && hour <= 18 ? "bg-indigo-600" : "bg-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-4 text-center">Mayor actividad: Lunes a Viernes, 9:00 - 18:00</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leads" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Leads Nuevos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">23</div>
                <p className="text-xs text-blue-600">Esta semana</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Leads Cualificados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">18</div>
                <p className="text-xs text-green-600">Listos para propuesta</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Score Promedio</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">7.2</div>
                <p className="text-xs text-yellow-600">Sobre 10 puntos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Tiempo de Conversión</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">5.2d</div>
                <p className="text-xs text-purple-600">Promedio</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Embudo de Conversión</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { stage: "Visitantes", count: 2450, percentage: 100 },
                  { stage: "Conversaciones", count: 1250, percentage: 51 },
                  { stage: "Leads", count: 156, percentage: 12.5 },
                  { stage: "Cualificados", count: 89, percentage: 7.1 },
                  { stage: "Propuestas", count: 34, percentage: 2.7 },
                  { stage: "Cerrados", count: 12, percentage: 1.0 },
                ].map((stage, index) => (
                  <div key={stage.stage} className="flex items-center space-x-4">
                    <div className="w-24 text-sm font-medium">{stage.stage}</div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-6 relative">
                          <div
                            className="bg-indigo-600 h-6 rounded-full flex items-center justify-center text-white text-xs font-medium"
                            style={{ width: `${Math.max(stage.percentage, 10)}%` }}
                          >
                            {stage.percentage}%
                          </div>
                        </div>
                        <div className="w-16 text-sm text-gray-600">{stage.count}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Rendimiento por Módulo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {state.modules
                    .filter((m) => m.isActive)
                    .map((module) => (
                      <div key={module.id} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">{module.name}</span>
                          <Badge variant="outline">{module.metrics?.uptime || 99}% uptime</Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs text-gray-600">
                          <div>Uso: {module.metrics?.usage || 0}</div>
                          <div>Errores: {module.metrics?.errorRate || 0}%</div>
                          <div>Actualizado: {module.lastUpdated?.toLocaleDateString("es-ES") || "N/A"}</div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Métricas del Sistema</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Tiempo de Respuesta API</span>
                    <span className="text-sm font-medium">120ms</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Disponibilidad</span>
                    <span className="text-sm font-medium text-green-600">99.9%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Uso de Almacenamiento</span>
                    <span className="text-sm font-medium">2.3GB / 50GB</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Llamadas API (mes)</span>
                    <span className="text-sm font-medium">15,420 / 50,000</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Alertas y Notificaciones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                  <Clock className="w-4 h-4 text-yellow-600" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-yellow-900">Uso de conversaciones al 85%</p>
                    <p className="text-xs text-yellow-700">Considera actualizar tu plan antes de fin de mes</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-green-900">Rendimiento excelente</p>
                    <p className="text-xs text-green-700">Todos los módulos funcionando correctamente</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
