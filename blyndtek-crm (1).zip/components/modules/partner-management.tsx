"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Handshake,
  Plus,
  Search,
  Filter,
  DollarSign,
  Users,
  TrendingUp,
  Mail,
  Phone,
  Building,
  Calendar,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useState } from "react"

export default function PartnerManagement() {
  const { state } = useApp()
  const [searchTerm, setSearchTerm] = useState("")

  const stats = {
    totalPartners: 8,
    activePartners: 5,
    totalCommissions: 15420,
    pendingCommissions: 2500,
  }

  const partners = [
    {
      id: "partner_1",
      name: "Agencia Colaboradora Madrid",
      email: "contacto@agenciacolaboradora.com",
      phone: "+34 600 555 666",
      company: "Agencia Colaboradora S.L.",
      type: "referral",
      commissionRate: 15,
      status: "active",
      clientsReferred: 12,
      totalCommissions: 8500,
      pendingCommissions: 1500,
      joinedAt: new Date("2023-06-01"),
      lastActivity: new Date("2024-01-15"),
    },
    {
      id: "partner_2",
      name: "Red Inmobiliaria Barcelona",
      email: "info@redinmobiliaria.com",
      phone: "+34 600 777 888",
      company: "Red Inmobiliaria Barcelona S.L.",
      type: "reseller",
      commissionRate: 20,
      status: "active",
      clientsReferred: 8,
      totalCommissions: 6920,
      pendingCommissions: 1000,
      joinedAt: new Date("2023-09-15"),
      lastActivity: new Date("2024-01-12"),
    },
  ]

  const commissions = [
    {
      id: "comm_1",
      partnerId: "partner_1",
      partnerName: "Agencia Colaboradora Madrid",
      clientName: "María González",
      amount: 750,
      type: "signup",
      status: "pending",
      date: new Date("2024-01-15"),
    },
    {
      id: "comm_2",
      partnerId: "partner_2",
      partnerName: "Red Inmobiliaria Barcelona",
      clientName: "Carlos Ruiz",
      amount: 500,
      type: "monthly_recurring",
      status: "paid",
      date: new Date("2024-01-10"),
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "inactive":
        return "bg-gray-100 text-gray-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "active":
        return "Activo"
      case "inactive":
        return "Inactivo"
      case "pending":
        return "Pendiente"
      default:
        return status
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "referral":
        return "Referido"
      case "reseller":
        return "Revendedor"
      case "affiliate":
        return "Afiliado"
      default:
        return type
    }
  }

  const getCommissionStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getCommissionStatusLabel = (status: string) => {
    switch (status) {
      case "paid":
        return "Pagada"
      case "pending":
        return "Pendiente"
      case "cancelled":
        return "Cancelada"
      default:
        return status
    }
  }

  const filteredPartners = partners.filter(
    (partner) =>
      partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner.company.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Handshake className="w-4 h-4 mr-2" />
              Total Partners
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stats.totalPartners}</div>
            <p className="text-xs text-green-600 mt-1">+2 este mes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Partners Activos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.activePartners}</div>
            <p className="text-xs text-green-600 mt-1">Generando referidos</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <DollarSign className="w-4 h-4 mr-2" />
              Comisiones Totales
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">€{stats.totalCommissions.toLocaleString()}</div>
            <p className="text-xs text-indigo-600 mt-1">Acumulado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Pendientes de Pago
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">€{stats.pendingCommissions.toLocaleString()}</div>
            <p className="text-xs text-yellow-600 mt-1">Por procesar</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="partners" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="partners">Partners</TabsTrigger>
          <TabsTrigger value="commissions">Comisiones</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="partners" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Gestión de Partners</CardTitle>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Nuevo Partner
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar partners..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filtros
                </Button>
              </div>

              <div className="space-y-4">
                {filteredPartners.map((partner) => (
                  <div
                    key={partner.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={`/placeholder.svg?height=48&width=48&text=${partner.name.charAt(0)}`} />
                          <AvatarFallback className="bg-indigo-100 text-indigo-600">
                            {partner.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>

                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-medium text-gray-900">{partner.name}</h3>
                            <Badge className={getStatusColor(partner.status)}>{getStatusLabel(partner.status)}</Badge>
                            <Badge variant="outline">{getTypeLabel(partner.type)}</Badge>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                            <div className="flex items-center space-x-1">
                              <Building className="w-4 h-4" />
                              <span>{partner.company}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Mail className="w-4 h-4" />
                              <span>{partner.email}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Phone className="w-4 h-4" />
                              <span>{partner.phone}</span>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Comisión:</span>
                              <span className="font-medium ml-1">{partner.commissionRate}%</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Referidos:</span>
                              <span className="font-medium ml-1">{partner.clientsReferred}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Total ganado:</span>
                              <span className="font-medium ml-1">€{partner.totalCommissions.toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Pendiente:</span>
                              <span className="font-medium ml-1 text-yellow-600">
                                €{partner.pendingCommissions.toLocaleString()}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-gray-500 mt-2">
                            <div className="flex items-center space-x-1">
                              <Calendar className="w-4 h-4" />
                              <span>Unido: {partner.joinedAt.toLocaleDateString("es-ES")}</span>
                            </div>
                            <span>•</span>
                            <span>Última actividad: {partner.lastActivity.toLocaleDateString("es-ES")}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Ver
                        </Button>
                        <Button variant="outline" size="sm">
                          <Mail className="w-4 h-4 mr-1" />
                          Contactar
                        </Button>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="w-4 h-4 mr-2" />
                              Editar información
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <DollarSign className="w-4 h-4 mr-2" />
                              Ver comisiones
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Users className="w-4 h-4 mr-2" />
                              Ver referidos
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Eliminar partner
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </div>
                ))}

                {filteredPartners.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Handshake className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {searchTerm ? "No se encontraron partners" : "No hay partners"}
                    </h3>
                    <p className="text-gray-500 mb-4">
                      {searchTerm
                        ? "Intenta con otros términos de búsqueda"
                        : "Invita a otros profesionales a unirse a tu red"}
                    </p>
                    {!searchTerm && (
                      <Button className="bg-indigo-600 hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Invitar primer partner
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="commissions" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Historial de Comisiones</CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filtros
                  </Button>
                  <Button className="bg-green-600 hover:bg-green-700" size="sm">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Procesar Pagos
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {commissions.map((commission) => (
                  <div key={commission.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-medium text-gray-900">{commission.partnerName}</h3>
                          <Badge className={getCommissionStatusColor(commission.status)}>
                            {getCommissionStatusLabel(commission.status)}
                          </Badge>
                        </div>

                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span>Cliente: {commission.clientName}</span>
                          <span>•</span>
                          <span>Tipo: {commission.type === "signup" ? "Registro" : "Recurrente"}</span>
                          <span>•</span>
                          <span>Fecha: {commission.date.toLocaleDateString("es-ES")}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="text-lg font-bold text-gray-900">€{commission.amount.toLocaleString()}</div>
                        </div>

                        {commission.status === "pending" && (
                          <Button variant="outline" size="sm">
                            Pagar
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {commissions.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <DollarSign className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No hay comisiones</h3>
                    <p className="text-gray-500">Las comisiones generadas aparecerán aquí</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Comisiones</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Comisión por Referido (%)</label>
                    <Input type="number" defaultValue="15" min="0" max="50" />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Comisión Recurrente (%)</label>
                    <Input type="number" defaultValue="10" min="0" max="30" />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Período de Tracking (días)</label>
                    <Input type="number" defaultValue="30" min="1" max="365" />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Método de Pago por Defecto</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md">
                      <option value="bank_transfer">Transferencia Bancaria</option>
                      <option value="paypal">PayPal</option>
                      <option value="stripe">Stripe</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Frecuencia de Pago</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md">
                      <option value="monthly">Mensual</option>
                      <option value="quarterly">Trimestral</option>
                      <option value="manual">Manual</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Mínimo para Pago (€)</label>
                    <Input type="number" defaultValue="100" min="0" />
                  </div>
                </div>
              </div>

              <Button className="bg-indigo-600 hover:bg-indigo-700">Guardar Configuración</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
