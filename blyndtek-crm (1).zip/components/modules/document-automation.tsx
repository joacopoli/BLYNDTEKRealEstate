"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  FileText,
  Plus,
  Search,
  Filter,
  Download,
  Send,
  Clock,
  CheckCircle,
  AlertCircle,
  Users,
  Edit,
  Trash2,
} from "lucide-react"
import { useState } from "react"

export default function DocumentAutomation() {
  const { state } = useApp()
  const [searchTerm, setSearchTerm] = useState("")

  // Usar documentos del estado global
  const documents = state.documents.map((doc) => ({
    id: doc.id,
    name: doc.name,
    type: doc.type,
    status: doc.status === "pending" ? "pending_signature" : doc.status,
    client: doc.clientName,
    created: doc.createdDate,
    signers: 2,
    signedBy: doc.status === "signed" ? 2 : 0,
  }))

  const stats = {
    totalDocuments: documents.length,
    pendingSignature: documents.filter((doc) => doc.status === "pending_signature").length,
    signed: documents.filter((doc) => doc.status === "signed").length,
    templates: 12,
  }

  const templates = [
    {
      id: "template_1",
      name: "Contrato de Arras",
      type: "contract",
      variables: 8,
      lastUsed: new Date("2024-01-15"),
    },
    {
      id: "template_2",
      name: "Acuerdo de Confidencialidad",
      type: "agreement",
      variables: 5,
      lastUsed: new Date("2024-01-10"),
    },
    {
      id: "template_3",
      name: "Informe de Valoración",
      type: "report",
      variables: 12,
      lastUsed: new Date("2024-01-12"),
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "signed":
        return "bg-green-100 text-green-800"
      case "pending_signature":
        return "bg-yellow-100 text-yellow-800"
      case "expired":
        return "bg-red-100 text-red-800"
      case "draft":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "signed":
        return "Firmado"
      case "pending_signature":
        return "Pendiente Firma"
      case "expired":
        return "Expirado"
      case "draft":
        return "Borrador"
      default:
        return status
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "contract":
        return "Contrato"
      case "agreement":
        return "Acuerdo"
      case "report":
        return "Reporte"
      default:
        return type
    }
  }

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <FileText className="w-4 h-4 mr-2" />
              Total Documentos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stats.totalDocuments}</div>
            <p className="text-xs text-green-600 mt-1">+5% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Pendientes Firma
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pendingSignature}</div>
            <p className="text-xs text-yellow-600 mt-1">Requieren atención</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <CheckCircle className="w-4 h-4 mr-2" />
              Firmados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.signed}</div>
            <p className="text-xs text-green-600 mt-1">Completados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Edit className="w-4 h-4 mr-2" />
              Plantillas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{stats.templates}</div>
            <p className="text-xs text-indigo-600 mt-1">Disponibles</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="documents" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="documents">Documentos</TabsTrigger>
          <TabsTrigger value="templates">Plantillas</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Gestión de Documentos</CardTitle>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Nuevo Documento
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar documentos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filtros
                </Button>
              </div>

              <div className="space-y-4">
                {documents.map((doc) => (
                  <div key={doc.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <div className="p-2 bg-indigo-100 rounded-lg">
                          <FileText className="w-5 h-5 text-indigo-600" />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-medium text-gray-900">{doc.name}</h3>
                            <Badge className={getStatusColor(doc.status)}>{getStatusLabel(doc.status)}</Badge>
                            <Badge variant="outline">{getTypeLabel(doc.type)}</Badge>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                            <span>Cliente: {doc.client}</span>
                            <span>•</span>
                            <span>Creado: {doc.created.toLocaleDateString("es-ES")}</span>
                          </div>

                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Users className="w-4 h-4" />
                              <span>
                                Firmantes: {doc.signedBy}/{doc.signers}
                              </span>
                            </div>
                            {doc.status === "pending_signature" && (
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4 text-yellow-500" />
                                <span className="text-yellow-600">Esperando firmas</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4 mr-1" />
                          Descargar
                        </Button>
                        {doc.status === "pending_signature" && (
                          <Button variant="outline" size="sm">
                            <Send className="w-4 h-4 mr-1" />
                            Recordar
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4 mr-1" />
                          Editar
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}

                {documents.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <FileText className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No hay documentos</h3>
                    <p className="text-gray-500 mb-4">Los documentos creados aparecerán aquí</p>
                    <Button className="bg-indigo-600 hover:bg-indigo-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Crear primer documento
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Plantillas de Documentos</CardTitle>
                <Button className="bg-indigo-600 hover:bg-indigo-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Nueva Plantilla
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {templates.map((template) => (
                  <Card key={template.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <FileText className="w-4 h-4 text-blue-600" />
                        </div>
                        <div>
                          <CardTitle className="text-base">{template.name}</CardTitle>
                          <p className="text-sm text-gray-500">{getTypeLabel(template.type)}</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex justify-between">
                          <span>Variables:</span>
                          <span>{template.variables}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Último uso:</span>
                          <span>{template.lastUsed.toLocaleDateString("es-ES")}</span>
                        </div>
                      </div>

                      <div className="flex space-x-2 mt-4">
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                          <Edit className="w-4 h-4 mr-1" />
                          Editar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {templates.length === 0 && (
                  <div className="col-span-full text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Edit className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No hay plantillas</h3>
                    <p className="text-gray-500 mb-4">Crea plantillas para generar documentos rápidamente</p>
                    <Button className="bg-indigo-600 hover:bg-indigo-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Primera plantilla
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Firma Digital</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-yellow-50 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <AlertCircle className="w-4 h-4 text-yellow-600" />
                  <span className="text-sm font-medium text-yellow-900">Módulo Activo</span>
                </div>
                <p className="text-sm text-yellow-700">
                  El módulo de automatización documental está activo. Configuración disponible para personalizar el
                  flujo de documentos.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Proveedor de Firma Digital</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>DocuSign</option>
                      <option>HelloSign</option>
                      <option>Adobe Sign</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Tiempo de Expiración (días)</label>
                    <Input type="number" defaultValue="30" className="mt-1" />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Recordatorios Automáticos</label>
                    <div className="space-y-1">
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked />
                        <span className="text-sm">Después de 3 días</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked />
                        <span className="text-sm">Después de 7 días</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" />
                        <span className="text-sm">1 día antes de expirar</span>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Idioma por Defecto</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Español</option>
                      <option>Inglés</option>
                      <option>Catalán</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Orden de Firma</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Secuencial</option>
                      <option>Paralelo</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Opciones Avanzadas</label>
                    <div className="space-y-1">
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked />
                        <span className="text-sm">Requerir autenticación por SMS</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" />
                        <span className="text-sm">Permitir firma en persona</span>
                      </label>
                      <label className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked />
                        <span className="text-sm">Generar certificado de finalización</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="bg-indigo-600 hover:bg-indigo-700">Guardar Configuración</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
