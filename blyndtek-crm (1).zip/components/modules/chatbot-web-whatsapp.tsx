"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Globe, BarChart3, Users, Clock, CheckCircle, TrendingUp, Bot, Smartphone } from "lucide-react"

export default function ChatbotWebWhatsApp() {
  const { state } = useApp()

  const module = state.modules.find((m) => m.id === "conversations")
  const config = module?.config || {}

  // Calcular stats basados en el estado actual
  const stats = {
    totalConversations: state.conversations.length * 625, // Simular volumen total
    activeChats: state.conversations.filter((c) => c.hasUnreadMessages).length,
    responseTime: "2.3s",
    satisfaction: 4.8,
    resolutionRate: 78,
    humanHandoff: state.conversations.filter((c) => c.isHumanTakeover).length,
  }

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <MessageSquare className="w-4 h-4 mr-2" />
              Conversaciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stats.totalConversations.toLocaleString()}</div>
            <p className="text-xs text-green-600 mt-1">+12% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Chats Activos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.activeChats}</div>
            <p className="text-xs text-blue-600 mt-1">En tiempo real</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Tiempo Respuesta
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.responseTime}</div>
            <p className="text-xs text-green-600 mt-1">Promedio</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Satisfacción
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.satisfaction}/5</div>
            <p className="text-xs text-yellow-600 mt-1">Valoración media</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Configuration */}
      <Tabs defaultValue="config" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="config">Configuración</TabsTrigger>
          <TabsTrigger value="web">Widget Web</TabsTrigger>
          <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="config" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bot className="w-5 h-5 mr-2" />
                Configuración de IA
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="model">Modelo de IA</Label>
                    <Select defaultValue={config.ai?.model || "gpt-4"}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar modelo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gpt-4">GPT-4 (Recomendado)</SelectItem>
                        <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                        <SelectItem value="claude-3">Claude 3</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="temperature">Creatividad (Temperature)</Label>
                    <Input
                      id="temperature"
                      type="number"
                      min="0"
                      max="1"
                      step="0.1"
                      defaultValue={config.ai?.temperature || 0.7}
                    />
                  </div>

                  <div>
                    <Label htmlFor="maxTokens">Máximo de Tokens</Label>
                    <Input id="maxTokens" type="number" defaultValue={config.ai?.maxTokens || 500} />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="confidence">Umbral de Confianza</Label>
                    <Input
                      id="confidence"
                      type="number"
                      min="0"
                      max="1"
                      step="0.1"
                      defaultValue={config.ai?.confidenceThreshold || 0.8}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch id="fallback" defaultChecked={config.ai?.fallbackToHuman !== false} />
                    <Label htmlFor="fallback">Transferir a humano si baja confianza</Label>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-900">Estado del Modelo</span>
                    </div>
                    <p className="text-sm text-blue-700">Modelo GPT-4 activo y funcionando correctamente</p>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="systemPrompt">Prompt del Sistema</Label>
                <Textarea
                  id="systemPrompt"
                  rows={4}
                  defaultValue={
                    config.ai?.systemPrompt ||
                    "Eres un asistente especializado en inmobiliaria que ayuda a los clientes con consultas sobre propiedades, valoraciones y servicios. Mantén un tono profesional y amigable."
                  }
                  placeholder="Define cómo debe comportarse la IA..."
                />
              </div>

              <Button className="bg-indigo-600 hover:bg-indigo-700">Guardar Configuración de IA</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="web" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                Widget Web
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="webEnabled" defaultChecked={config.webWidget?.enabled !== false} />
                    <Label htmlFor="webEnabled">Activar Widget Web</Label>
                  </div>

                  <div>
                    <Label htmlFor="position">Posición</Label>
                    <Select defaultValue={config.webWidget?.position || "bottom-right"}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bottom-right">Abajo Derecha</SelectItem>
                        <SelectItem value="bottom-left">Abajo Izquierda</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="theme">Tema</Label>
                    <Select defaultValue={config.webWidget?.theme || "light"}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Claro</SelectItem>
                        <SelectItem value="dark">Oscuro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch id="collectEmail" defaultChecked={config.webWidget?.collectEmail !== false} />
                    <Label htmlFor="collectEmail">Solicitar Email</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch id="collectPhone" defaultChecked={config.webWidget?.collectPhone !== false} />
                    <Label htmlFor="collectPhone">Solicitar Teléfono</Label>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="welcomeMessage">Mensaje de Bienvenida</Label>
                    <Textarea
                      id="welcomeMessage"
                      rows={3}
                      defaultValue={config.webWidget?.welcomeMessage || "¡Hola! ¿En qué puedo ayudarte hoy?"}
                    />
                  </div>

                  <div>
                    <Label htmlFor="offlineMessage">Mensaje Fuera de Horario</Label>
                    <Textarea
                      id="offlineMessage"
                      rows={3}
                      defaultValue={
                        config.webWidget?.offlineMessage ||
                        "Estamos fuera de horario. Déjanos tu consulta y te responderemos pronto."
                      }
                    />
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium mb-2">Vista Previa</h4>
                    <div className="bg-white border rounded-lg p-3 shadow-sm">
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                        <span className="font-medium">Asistente IA</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        {config.webWidget?.welcomeMessage || "¡Hola! ¿En qué puedo ayudarte hoy?"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="bg-indigo-600 hover:bg-indigo-700">Guardar Configuración Web</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="whatsapp" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Smartphone className="w-5 h-5 mr-2" />
                WhatsApp Business
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="whatsappEnabled" defaultChecked={config.whatsapp?.enabled !== false} />
                    <Label htmlFor="whatsappEnabled">Activar WhatsApp</Label>
                  </div>

                  <div>
                    <Label htmlFor="phoneNumber">Número de Teléfono</Label>
                    <Input
                      id="phoneNumber"
                      defaultValue={config.whatsapp?.phoneNumber || "+34600123456"}
                      placeholder="+34600123456"
                    />
                  </div>

                  <div>
                    <Label htmlFor="whatsappWelcome">Mensaje de Bienvenida</Label>
                    <Textarea
                      id="whatsappWelcome"
                      rows={3}
                      defaultValue={
                        config.whatsapp?.welcomeMessage ||
                        "¡Bienvenido a Inmobiliaria Premium! ¿En qué podemos ayudarte?"
                      }
                    />
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-900">Estado de Conexión</span>
                    </div>
                    <p className="text-sm text-green-700">WhatsApp Business API conectado correctamente</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label>Opciones del Menú</Label>
                    <div className="space-y-2 mt-2">
                      {[
                        { text: "Ver propiedades disponibles", action: "properties" },
                        { text: "Solicitar valoración", action: "valuation" },
                        { text: "Agendar visita", action: "appointment" },
                        { text: "Hablar con agente", action: "human" },
                      ].map((option, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 border rounded">
                          <span className="text-sm font-medium">{index + 1}.</span>
                          <span className="text-sm flex-1">{option.text}</span>
                          <Badge variant="outline" className="text-xs">
                            {option.action}
                          </Badge>
                        </div>
                      ))}
                    </div>
                    <Button variant="outline" size="sm" className="mt-2 bg-transparent">
                      Agregar Opción
                    </Button>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-medium mb-2">Vista Previa del Menú</h4>
                    <div className="bg-white border rounded-lg p-3 shadow-sm">
                      <p className="text-sm mb-2">{config.whatsapp?.welcomeMessage || "¡Bienvenido!"}</p>
                      <div className="space-y-1">
                        <p className="text-sm text-blue-600">1. Ver propiedades disponibles</p>
                        <p className="text-sm text-blue-600">2. Solicitar valoración</p>
                        <p className="text-sm text-blue-600">3. Agendar visita</p>
                        <p className="text-sm text-blue-600">4. Hablar con agente</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <Button className="bg-green-600 hover:bg-green-700">Guardar Configuración WhatsApp</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Métricas de Rendimiento
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tasa de Resolución</span>
                  <span className="text-sm font-medium">{stats.resolutionRate}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Transferencia a Humano</span>
                  <span className="text-sm font-medium">{stats.humanHandoff} casos</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tiempo Promedio de Respuesta</span>
                  <span className="text-sm font-medium">{stats.responseTime}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Satisfacción del Cliente</span>
                  <span className="text-sm font-medium">{stats.satisfaction}/5</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Canales de Conversación</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm">WhatsApp</span>
                    </div>
                    <span className="text-sm font-medium">65%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Widget Web</span>
                    </div>
                    <span className="text-sm font-medium">35%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Horarios de Mayor Actividad</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {["L", "M", "X", "J", "V", "S", "D"].map((day, index) => (
                  <div key={day} className="text-center">
                    <div className="text-xs text-gray-500 mb-2">{day}</div>
                    <div className="space-y-1">
                      {Array.from({ length: 24 }, (_, hour) => (
                        <div
                          key={hour}
                          className={`h-1 rounded ${
                            index < 5 && hour >= 9 && hour <= 18 ? "bg-indigo-600" : "bg-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-4 text-center">Mayor actividad: Lunes a Viernes, 9:00 - 18:00</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
