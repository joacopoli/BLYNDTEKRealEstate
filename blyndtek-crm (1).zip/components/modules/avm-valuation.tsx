"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Home,
  TrendingUp,
  MapPin,
  Calculator,
  FileText,
  Clock,
  CheckCircle,
  AlertTriangle,
  DollarSign,
  BarChart3,
  Plus,
  Search,
  Filter,
} from "lucide-react"
import { useState } from "react"

export default function AVMValuation() {
  const { state } = useApp()
  const [activeTab, setActiveTab] = useState("new-valuation")

  // Usar las propiedades del estado global
  const recentValuations = state.properties.map((property) => ({
    id: property.id,
    address: property.address,
    type: property.type,
    value: property.value,
    confidence: property.confidence,
    status: property.status,
    date: property.requestDate,
  }))

  const stats = {
    totalValuations: recentValuations.length,
    avgAccuracy:
      recentValuations.length > 0
        ? recentValuations.reduce((acc, val) => acc + val.confidence, 0) / recentValuations.length
        : 0,
    avgTime: "45s",
    completedToday: recentValuations.filter(
      (val) => val.date.toDateString() === new Date().toDateString() && val.status === "completed",
    ).length,
  }

  const getPropertyTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      apartment: "Apartamento",
      house: "Casa",
      commercial: "Comercial",
      land: "Terreno",
      office: "Oficina",
    }
    return types[type] || type
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "failed":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return "Completada"
      case "processing":
        return "Procesando"
      case "failed":
        return "Error"
      default:
        return status
    }
  }

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Calculator className="w-4 h-4 mr-2" />
              Total Valoraciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stats.totalValuations}</div>
            <p className="text-xs text-green-600 mt-1">+8% vs mes anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              Precisión Promedio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.avgAccuracy.toFixed(1)}%</div>
            <p className="text-xs text-green-600 mt-1">Muy alta precisión</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Clock className="w-4 h-4 mr-2" />
              Tiempo Promedio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.avgTime}</div>
            <p className="text-xs text-blue-600 mt-1">Procesamiento rápido</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <CheckCircle className="w-4 h-4 mr-2" />
              Hoy Completadas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-indigo-600">{stats.completedToday}</div>
            <p className="text-xs text-indigo-600 mt-1">Valoraciones hoy</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="new-valuation">Nueva Valoración</TabsTrigger>
          <TabsTrigger value="history">Historial</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        <TabsContent value="new-valuation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Home className="w-5 h-5 mr-2" />
                Nueva Valoración AVM
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="address">Dirección de la Propiedad</Label>
                    <Input id="address" placeholder="Ej: Calle Mayor 123, Madrid" />
                  </div>

                  <div>
                    <Label htmlFor="propertyType">Tipo de Propiedad</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="apartment">Apartamento</SelectItem>
                        <SelectItem value="house">Casa</SelectItem>
                        <SelectItem value="commercial">Comercial</SelectItem>
                        <SelectItem value="land">Terreno</SelectItem>
                        <SelectItem value="office">Oficina</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="size">Superficie (m²)</Label>
                      <Input id="size" type="number" placeholder="85" />
                    </div>
                    <div>
                      <Label htmlFor="bedrooms">Habitaciones</Label>
                      <Input id="bedrooms" type="number" placeholder="2" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="bathrooms">Baños</Label>
                      <Input id="bathrooms" type="number" placeholder="1" />
                    </div>
                    <div>
                      <Label htmlFor="yearBuilt">Año Construcción</Label>
                      <Input id="yearBuilt" type="number" placeholder="1995" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="condition">Estado de la Propiedad</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar estado" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excellent">Excelente</SelectItem>
                        <SelectItem value="good">Bueno</SelectItem>
                        <SelectItem value="fair">Regular</SelectItem>
                        <SelectItem value="poor">Malo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Características Adicionales</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {[
                        "Ascensor",
                        "Parking",
                        "Terraza",
                        "Jardín",
                        "Piscina",
                        "Calefacción",
                        "Aire Acond.",
                        "Reformado",
                      ].map((feature) => (
                        <label key={feature} className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">{feature}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Calculator className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-900">Valoración Automática</span>
                    </div>
                    <p className="text-sm text-blue-700">
                      El sistema analizará automáticamente datos de mercado, comparables y características de la
                      propiedad.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <Button className="bg-indigo-600 hover:bg-indigo-700 flex-1">
                  <Calculator className="w-4 h-4 mr-2" />
                  Generar Valoración
                </Button>
                <Button variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  Guardar Borrador
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Historial de Valoraciones</CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    Filtros
                  </Button>
                  <Button variant="outline" size="sm">
                    <Search className="w-4 h-4 mr-2" />
                    Buscar
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentValuations.map((valuation) => (
                  <div
                    key={valuation.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className="p-2 bg-indigo-100 rounded-lg">
                            <Home className="w-4 h-4 text-indigo-600" />
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900">{valuation.address}</h3>
                            <p className="text-sm text-gray-500">
                              {getPropertyTypeLabel(valuation.type)} • {valuation.date.toLocaleDateString("es-ES")}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-6 mt-3">
                          <div className="flex items-center space-x-2">
                            <DollarSign className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-medium">
                              {valuation.status === "completed"
                                ? `€${valuation.value.toLocaleString()}`
                                : "Procesando..."}
                            </span>
                          </div>

                          {valuation.status === "completed" && (
                            <div className="flex items-center space-x-2">
                              <BarChart3 className="w-4 h-4 text-blue-600" />
                              <span className="text-sm">Confianza: {valuation.confidence}%</span>
                            </div>
                          )}

                          <Badge className={getStatusColor(valuation.status)}>{getStatusLabel(valuation.status)}</Badge>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        {valuation.status === "completed" && (
                          <>
                            <Button variant="outline" size="sm">
                              <FileText className="w-4 h-4 mr-1" />
                              Reporte
                            </Button>
                            <Button variant="outline" size="sm">
                              <MapPin className="w-4 h-4 mr-1" />
                              Mapa
                            </Button>
                          </>
                        )}
                        {valuation.status === "processing" && (
                          <div className="flex items-center space-x-2">
                            <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                            <span className="text-sm text-blue-600">Procesando...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {recentValuations.length === 0 && (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Calculator className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No hay valoraciones</h3>
                    <p className="text-gray-500 mb-4">Las valoraciones completadas aparecerán aquí</p>
                    <Button onClick={() => setActiveTab("new-valuation")} className="bg-indigo-600 hover:bg-indigo-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Primera Valoración
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración del Modelo AVM</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="confidence">Umbral de Confianza Mínimo</Label>
                    <Input id="confidence" type="number" min="0" max="100" defaultValue="85" />
                    <p className="text-xs text-gray-500 mt-1">
                      Valoraciones con confianza menor serán marcadas como "Revisar"
                    </p>
                  </div>

                  <div>
                    <Label>Fuentes de Datos</Label>
                    <div className="space-y-2 mt-2">
                      {["Idealista", "Fotocasa", "Habitaclia", "Pisos.com"].map((source) => (
                        <label key={source} className="flex items-center space-x-2">
                          <input type="checkbox" defaultChecked className="rounded" />
                          <span className="text-sm">{source}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="comparables">Número de Comparables</Label>
                    <Select defaultValue="5">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3 propiedades</SelectItem>
                        <SelectItem value="5">5 propiedades</SelectItem>
                        <SelectItem value="10">10 propiedades</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="radius">Radio de Búsqueda (km)</Label>
                    <Input id="radius" type="number" min="0.5" max="5" step="0.5" defaultValue="2" />
                  </div>

                  <div>
                    <Label htmlFor="maxAge">Antigüedad Máxima de Datos (meses)</Label>
                    <Input id="maxAge" type="number" min="1" max="12" defaultValue="6" />
                  </div>

                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-600" />
                      <span className="text-sm font-medium text-yellow-900">Configuración Avanzada</span>
                    </div>
                    <p className="text-sm text-yellow-700">
                      Cambios en estos parámetros pueden afectar la precisión del modelo. Se recomienda mantener los
                      valores por defecto.
                    </p>
                  </div>
                </div>
              </div>

              <Button className="bg-indigo-600 hover:bg-indigo-700">Guardar Configuración</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Reportes y Exportación</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Formato de Reporte</Label>
                  <Select defaultValue="pdf">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF Completo</SelectItem>
                      <SelectItem value="summary">Resumen PDF</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Incluir en Reportes</Label>
                  <div className="space-y-1">
                    {["Comparables", "Análisis de Mercado", "Fotos", "Mapa"].map((item) => (
                      <label key={item} className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked className="rounded" />
                        <span className="text-sm">{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
