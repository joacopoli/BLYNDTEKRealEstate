"use client"

import { useApp } from "@/lib/context/app-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CreditCard,
  Download,
  Calendar,
  MessageSquare,
  Home,
  FileText,
  Crown,
  Check,
  X,
  AlertTriangle,
} from "lucide-react"

export default function BillingPanel() {
  const { state } = useApp()

  const currentPlan = {
    name: "Enterprise",
    price: 299,
    billing: "monthly",
    features: [
      "Conversaciones ilimitadas",
      "Hasta 25 usuarios",
      "Todos los módulos incluidos",
      "Soporte prioritario 24/7",
      "Integraciones avanzadas",
      "Reportes personalizados",
      "API completa",
      "Marca blanca",
    ],
  }

  const plans = [
    {
      name: "Starter",
      price: 49,
      billing: "monthly",
      description: "Perfecto para equipos pequeños",
      features: ["1,000 conversaciones/mes", "Hasta 3 usuarios", "Chatbot básico", "CRM básico", "Soporte por email"],
      limitations: ["Sin valoraciones AVM", "Sin automatización documental", "Sin analytics avanzado"],
      popular: false,
    },
    {
      name: "Professional",
      price: 149,
      billing: "monthly",
      description: "Para equipos en crecimiento",
      features: [
        "5,000 conversaciones/mes",
        "Hasta 10 usuarios",
        "Todos los chatbots",
        "CRM completo",
        "100 valoraciones AVM/mes",
        "Automatización básica",
        "Soporte prioritario",
      ],
      limitations: ["Analytics limitado", "Sin marca blanca"],
      popular: true,
    },
    {
      name: "Enterprise",
      price: 299,
      billing: "monthly",
      description: "Para empresas grandes",
      features: [
        "Conversaciones ilimitadas",
        "Hasta 25 usuarios",
        "Todos los módulos",
        "Valoraciones ilimitadas",
        "Automatización completa",
        "Analytics avanzado",
        "API completa",
        "Marca blanca",
        "Soporte 24/7",
      ],
      limitations: [],
      popular: false,
    },
  ]

  const usage = state.company?.billingInfo?.usage || {
    conversations: 0,
    valuations: 0,
    documents: 0,
    voiceCalls: 0,
    apiCalls: 0,
    storage: 0,
  }

  const limits = state.company?.limits || {
    conversations: 1,
    valuations: 1,
    documents: 1,
    users: 1,
    storage: 1,
    apiCalls: 1,
  }

  const getUsagePercentage = (current: number, limit: number) => {
    if (limit === 0) return 0
    return Math.min((current / limit) * 100, 100)
  }

  const getUsageColor = (percentage: number) => {
    if (percentage >= 90) return "text-red-600"
    if (percentage >= 75) return "text-yellow-600"
    return "text-green-600"
  }

  const invoices = [
    {
      id: "inv_001",
      date: new Date("2024-01-01"),
      amount: 299,
      status: "paid",
      period: "Enero 2024",
    },
    {
      id: "inv_002",
      date: new Date("2023-12-01"),
      amount: 299,
      status: "paid",
      period: "Diciembre 2023",
    },
    {
      id: "inv_003",
      date: new Date("2023-11-01"),
      amount: 299,
      status: "paid",
      period: "Noviembre 2023",
    },
  ]

  return (
    <div className="h-full overflow-y-auto p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Facturación y Planes</h1>
          <p className="text-gray-600 mt-1">Gestiona tu suscripción y uso de la plataforma</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge className="bg-indigo-100 text-indigo-800">
            <Crown className="w-3 h-3 mr-1" />
            {currentPlan.name}
          </Badge>
        </div>
      </div>

      {/* Current Plan Overview */}
      <Card className="border-indigo-200 bg-indigo-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Crown className="w-5 h-5 mr-2 text-indigo-600" />
              Plan Actual: {currentPlan.name}
            </CardTitle>
            <div className="text-right">
              <div className="text-2xl font-bold text-indigo-600">€{currentPlan.price}</div>
              <div className="text-sm text-indigo-600">por mes</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium mb-3">Características incluidas:</h4>
              <div className="space-y-2">
                {currentPlan.features.slice(0, 4).map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-3">Próxima facturación</p>
                <p className="text-lg font-semibold">
                  {state.company?.billingInfo?.nextBillingDate?.toLocaleDateString("es-ES") || "N/A"}
                </p>
                <Button className="mt-3 bg-indigo-600 hover:bg-indigo-700">Gestionar Suscripción</Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <MessageSquare className="w-4 h-4 mr-2" />
              Conversaciones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold">{usage.conversations.toLocaleString()}</span>
              <span
                className={`text-sm font-medium ${getUsageColor(getUsagePercentage(usage.conversations, limits.conversations))}`}
              >
                {getUsagePercentage(usage.conversations, limits.conversations).toFixed(0)}%
              </span>
            </div>
            <Progress value={getUsagePercentage(usage.conversations, limits.conversations)} className="h-2 mb-2" />
            <p className="text-xs text-gray-500">
              {limits.conversations === 0 ? "Ilimitadas" : `de ${limits.conversations.toLocaleString()} incluidas`}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Home className="w-4 h-4 mr-2" />
              Valoraciones AVM
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold">{usage.valuations}</span>
              <span
                className={`text-sm font-medium ${getUsageColor(getUsagePercentage(usage.valuations, limits.valuations))}`}
              >
                {getUsagePercentage(usage.valuations, limits.valuations).toFixed(0)}%
              </span>
            </div>
            <Progress value={getUsagePercentage(usage.valuations, limits.valuations)} className="h-2 mb-2" />
            <p className="text-xs text-gray-500">
              {limits.valuations === 0 ? "Ilimitadas" : `de ${limits.valuations} incluidas`}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <FileText className="w-4 h-4 mr-2" />
              Documentos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold">{usage.documents}</span>
              <span
                className={`text-sm font-medium ${getUsageColor(getUsagePercentage(usage.documents, limits.documents))}`}
              >
                {getUsagePercentage(usage.documents, limits.documents).toFixed(0)}%
              </span>
            </div>
            <Progress value={getUsagePercentage(usage.documents, limits.documents)} className="h-2 mb-2" />
            <p className="text-xs text-gray-500">
              {limits.documents === 0 ? "Ilimitados" : `de ${limits.documents} incluidos`}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="usage" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="usage">Uso</TabsTrigger>
          <TabsTrigger value="plans">Planes</TabsTrigger>
          <TabsTrigger value="invoices">Facturas</TabsTrigger>
          <TabsTrigger value="payment">Pago</TabsTrigger>
        </TabsList>

        <TabsContent value="usage" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Detalles de Uso Mensual</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Uso por Módulo</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Chatbot Web/WhatsApp</span>
                        <span className="text-sm font-medium">{usage.conversations} conversaciones</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Valoración AVM</span>
                        <span className="text-sm font-medium">{usage.valuations} valoraciones</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Automatización Documental</span>
                        <span className="text-sm font-medium">{usage.documents} documentos</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Llamadas API</span>
                        <span className="text-sm font-medium">{usage.apiCalls.toLocaleString()} llamadas</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Almacenamiento</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Usado</span>
                        <span className="text-sm font-medium">{usage.storage} GB</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Disponible</span>
                        <span className="text-sm font-medium">{limits.storage} GB</span>
                      </div>
                      <Progress value={getUsagePercentage(usage.storage, limits.storage)} className="h-2" />
                    </div>
                  </div>
                </div>

                {getUsagePercentage(usage.conversations, limits.conversations) > 80 && (
                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-600" />
                      <span className="text-sm font-medium text-yellow-900">Límite de uso próximo</span>
                    </div>
                    <p className="text-sm text-yellow-700">
                      Has usado el {getUsagePercentage(usage.conversations, limits.conversations).toFixed(0)}% de tus
                      conversaciones mensuales. Considera actualizar tu plan.
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plans" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card
                key={plan.name}
                className={`relative ${plan.popular ? "ring-2 ring-indigo-500 scale-105" : ""} ${
                  plan.name === currentPlan.name ? "bg-indigo-50 border-indigo-200" : ""
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-indigo-600 text-white">Más Popular</Badge>
                  </div>
                )}
                <CardHeader>
                  <div className="text-center">
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{plan.description}</p>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">€{plan.price}</span>
                      <span className="text-gray-600">/mes</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm mb-2">Incluye:</h4>
                      <div className="space-y-1">
                        {plan.features.map((feature, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <Check className="w-3 h-3 text-green-600" />
                            <span className="text-xs">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {plan.limitations.length > 0 && (
                      <div>
                        <h4 className="font-medium text-sm mb-2">Limitaciones:</h4>
                        <div className="space-y-1">
                          {plan.limitations.map((limitation, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <X className="w-3 h-3 text-red-600" />
                              <span className="text-xs text-gray-600">{limitation}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <Button
                      className={`w-full ${
                        plan.name === currentPlan.name
                          ? "bg-gray-400 cursor-not-allowed"
                          : plan.popular
                            ? "bg-indigo-600 hover:bg-indigo-700"
                            : "bg-gray-600 hover:bg-gray-700"
                      }`}
                      disabled={plan.name === currentPlan.name}
                    >
                      {plan.name === currentPlan.name ? "Plan Actual" : "Cambiar Plan"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="invoices" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Historial de Facturas</CardTitle>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Descargar Todas
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {invoices.map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <FileText className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Factura #{invoice.id}</h3>
                        <p className="text-sm text-gray-600">{invoice.period}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="font-medium">€{invoice.amount}</div>
                        <div className="text-sm text-gray-600">{invoice.date.toLocaleDateString("es-ES")}</div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Pagada</Badge>
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-1" />
                        PDF
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="w-5 h-5 mr-2" />
                  Método de Pago
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-100 rounded">
                        <CreditCard className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {state.company?.billingInfo?.paymentMethod?.brand || "Visa"} ****
                          {state.company?.billingInfo?.paymentMethod?.last4 || "4242"}
                        </p>
                        <p className="text-sm text-gray-600">
                          Expira {state.company?.billingInfo?.paymentMethod?.expiryMonth || "12"}/
                          {state.company?.billingInfo?.paymentMethod?.expiryYear || "2025"}
                        </p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Editar
                    </Button>
                  </div>

                  <Button variant="outline" className="w-full bg-transparent">
                    Agregar Método de Pago
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Información de Facturación
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Nombre de la Empresa</label>
                    <p className="text-sm text-gray-600 mt-1">{state.company?.name || "Inmobiliaria Premium S.L."}</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Email de Facturación</label>
                    <p className="text-sm text-gray-600 mt-1">{state.user?.email || "admin@inmobiliaria.com"}</p>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Dirección Fiscal</label>
                    <p className="text-sm text-gray-600 mt-1">
                      Calle Mayor 123
                      <br />
                      28001 Madrid, España
                    </p>
                  </div>

                  <Button variant="outline" className="w-full bg-transparent">
                    Actualizar Información
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
