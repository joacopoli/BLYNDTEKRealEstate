"use client"

import type { Conversation, Message, User } from "@/lib/types"
import ConversationList from "./conversation-list"
import ChatWindow from "./chat-window"

interface ChatInterfaceProps {
  conversations: Conversation[]
  selectedConversation: Conversation | null
  onSelectConversation: (conversation: Conversation | null) => void
  onSendMessage: (conversationId: string, message: Message) => void
  onToggleAi: (conversationId: string, enabled: boolean) => void
  currentUser: User | null
}

export default function ChatInterface({
  conversations,
  selectedConversation,
  onSelectConversation,
  onSendMessage,
  onToggleAi,
  currentUser,
}: ChatInterfaceProps) {
  return (
    <div className="flex h-full bg-white">
      <ConversationList
        conversations={conversations}
        selectedConversation={selectedConversation}
        onSelectConversation={onSelectConversation}
      />
      <ChatWindow
        conversation={selectedConversation}
        onSendMessage={onSendMessage}
        onToggleAi={onToggleAi}
        currentUser={currentUser}
      />
    </div>
  )
}
