"use client"

import type { Conversation } from "@/lib/types"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Bot, User } from 'lucide-react'

interface ConversationListProps {
  conversations: Conversation[]
  selectedConversation: Conversation | null
  onSelectConversation: (conversation: Conversation) => void
}

export default function ConversationList({
  conversations,
  selectedConversation,
  onSelectConversation,
}: ConversationListProps) {
  return (
    <div className="w-1/3 border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold">Conversaciones</h2>
      </div>
      <div className="flex-1 overflow-y-auto">
        {conversations.map((conv) => (
          <button
            key={conv.id}
            onClick={() => onSelectConversation(conv)}
            className={`w-full text-left p-4 border-b hover:bg-gray-50 ${
              selectedConversation?.id === conv.id ? "bg-violet-50" : ""
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarFallback className="bg-gray-200">{conv.client.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{conv.client.name}</p>
                  <p className="text-sm text-gray-500 truncate max-w-xs">{conv.lastMessage?.content}</p>
                </div>
              </div>
              {conv.hasUnreadMessages && <div className="w-2.5 h-2.5 bg-violet-500 rounded-full"></div>}
            </div>
            <div className="flex items-center justify-between mt-2 text-xs text-gray-400">
              <span>{conv.lastMessage?.timestamp.toLocaleTimeString()}</span>
              <div className="flex items-center space-x-2">
                {conv.isHumanTakeover ? (
                  <Badge variant="secondary" className="flex items-center space-x-1">
                    <User className="w-3 h-3" />
                    <span>Humano</span>
                  </Badge>
                ) : (
                  <Badge variant="outline" className="flex items-center space-x-1">
                    <Bot className="w-3 h-3" />
                    <span>IA Activa</span>
                  </Badge>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
