"use client"

import { useState } from "react"
import type { Conversation, Message, User } from "@/lib/types"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Bot, Send, UserIcon } from 'lucide-react'

interface ChatWindowProps {
  conversation: Conversation | null
  onSendMessage: (conversationId: string, message: Message) => void
  onToggleAi: (conversationId: string, enabled: boolean) => void
  currentUser: User | null
}

export default function ChatWindow({ conversation, onSendMessage, onToggleAi, currentUser }: ChatWindowProps) {
  const [newMessage, setNewMessage] = useState("")

  const handleSendMessage = () => {
    if (newMessage.trim() === "" || !conversation) return
    const message: Message = {
      id: `msg_${Date.now()}`,
      content: newMessage,
      sender: "agent",
      timestamp: new Date(),
    }
    onSendMessage(conversation.id, message)
    setNewMessage("")
  }

  if (!conversation) {
    return (
      <div className="w-2/3 flex items-center justify-center text-gray-500">
        <p>Selecciona una conversación para empezar a chatear.</p>
      </div>
    )
  }

  return (
    <div className="w-2/3 flex flex-col h-full">
      <div className="p-4 border-b flex items-center justify-between">
        <div>
          <h3 className="font-semibold">{conversation.client.name}</h3>
          <p className="text-sm text-gray-500">{conversation.client.phone}</p>
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor="ai-switch">IA Activa</Label>
          <Switch
            id="ai-switch"
            checked={conversation.aiEnabled}
            onCheckedChange={(checked) => onToggleAi(conversation.id, checked)}
          />
        </div>
      </div>
      <div className="flex-1 p-6 overflow-y-auto bg-gray-50">
        <div className="space-y-4">
          {conversation.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-end gap-2 ${msg.sender === "client" ? "justify-start" : "justify-end"}`}
            >
              {msg.sender === "client" && (
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-gray-300">{conversation.client.name.charAt(0)}</AvatarFallback>
                </Avatar>
              )}
              <div
                className={`max-w-md p-3 rounded-lg ${
                  msg.sender === "client" ? "bg-white shadow-sm" : msg.sender === "ai" ? "bg-violet-100" : "bg-blue-100"
                }`}
              >
                <p className="text-sm">{msg.content}</p>
                <p className="text-xs text-gray-400 mt-1 text-right">{msg.timestamp.toLocaleTimeString()}</p>
              </div>
              {msg.sender !== "client" && (
                <Avatar className="w-8 h-8">
                  <AvatarFallback className={msg.sender === "ai" ? "bg-violet-200" : "bg-blue-200"}>
                    {msg.sender === "ai" ? <Bot className="w-4 h-4" /> : <UserIcon className="w-4 h-4" />}
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
        </div>
      </div>
      <div className="p-4 border-t bg-white">
        <div className="relative">
          <Input
            placeholder="Escribe un mensaje..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            disabled={conversation.aiEnabled}
          />
          <Button
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
            onClick={handleSendMessage}
            disabled={conversation.aiEnabled}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        {conversation.aiEnabled && (
          <p className="text-xs text-center text-gray-500 mt-2">
            La IA está gestionando esta conversación. Desactívala para responder manualmente.
          </p>
        )}
      </div>
    </div>
  )
}
