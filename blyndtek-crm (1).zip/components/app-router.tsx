"use client"

import { useApp } from "@/lib/context/app-context"
import MainApp from "@/components/main-app"
import LoginForm from "@/components/auth/login-form"

export default function AppRouter() {
  const { state } = useApp()
  return state.isAuthenticated ? <MainApp /> : <LoginForm />
}
