"use client"

import type React from "react"

import Image from "next/image"
import { useApp } from "@/lib/context/app-context"
import {
  LayoutDashboard,
  MessageSquare,
  Phone,
  Users,
  Home,
  FileText,
  BarChart3,
  Settings,
  CreditCard,
  LogOut,
  Lock,
} from "lucide-react"
import type { ServiceId } from "@/lib/types"

export default function Sidebar() {
  const { state, dispatch } = useApp()
  const { activeService, company } = state

  const services = company?.services || []
  const serviceMap = new Map(services.map((s) => [s.id, s]))

  const handleNavigation = (service: ServiceId) => {
    dispatch({ type: "SET_ACTIVE_SERVICE", payload: service })
  }

  const navItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "conversations", label: "Conversaciones", icon: MessageSquare },
    { id: "voice", label: "Llamadas IA", icon: Phone },
    { id: "leads", label: "Leads", icon: Users },
    { id: "valuations", label: "Valoraciones", icon: Home },
    { id: "documents", label: "Documentos", icon: FileText },
    { id: "reports", label: "Reportes", icon: BarChart3 },
  ] as const

  const bottomNavItems = [
    { id: "billing", label: "Facturación y Plan", icon: CreditCard },
    { id: "settings", label: "Configuración", icon: Settings },
  ] as const

  const NavLink = ({ item }: { item: { id: ServiceId; label: string; icon: React.ElementType } }) => {
    const service = serviceMap.get(item.id)
    const isActive = activeService === item.id
    const isLocked = item.id !== "dashboard" && (!service || !service.isActive)

    return (
      <button
        onClick={() => !isLocked && handleNavigation(item.id)}
        disabled={isLocked}
        className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg transition-colors text-sm font-medium ${
          isActive
            ? "bg-violet-100 text-violet-700"
            : isLocked
              ? "text-gray-400 cursor-not-allowed"
              : "text-gray-600 hover:bg-gray-100"
        }`}
      >
        <item.icon className="w-5 h-5" />
        <span>{item.label}</span>
        {isLocked && <Lock className="w-3 h-3 ml-auto text-gray-400" />}
      </button>
    )
  }

  return (
    <aside className="w-64 flex flex-col bg-white border-r border-gray-200 p-4">
      <div className="flex items-center space-x-3 mb-8 px-2">
        <Image src="/images/blyndtek-logo.png" alt="Blyndtek Logo" width={32} height={32} />
        <span className="text-xl font-bold text-gray-800">Blyndtek</span>
      </div>

      <nav className="flex-1 flex flex-col space-y-2">
        {navItems.map((item) => (
          <NavLink key={item.id} item={item} />
        ))}
      </nav>

      <div className="flex flex-col space-y-2 border-t pt-4">
        {bottomNavItems.map((item) => (
          <NavLink key={item.id} item={item} />
        ))}
        <button
          onClick={() => dispatch({ type: "LOGOUT" })}
          className="w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg transition-colors text-sm font-medium text-gray-600 hover:bg-gray-100"
        >
          <LogOut className="w-5 h-5" />
          <span>Cerrar Sesión</span>
        </button>
      </div>
    </aside>
  )
}
