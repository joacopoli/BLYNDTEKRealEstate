"use client"

import { useApp } from "@/lib/context/app-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Home, MessageSquare, Users, BarChart3, MoreHorizontal, FileText, Handshake, Phone } from "lucide-react"

export default function MobileBottomNav() {
  const { state, dispatch } = useApp()

  const mainItems = [
    { id: "dashboard", label: "Inicio", icon: Home },
    {
      id: "conversations",
      label: "Chat",
      icon: MessageSquare,
      badge: state.conversations.filter((c) => c.unreadCount > 0).length,
    },
    { id: "crm-ai-leads", label: "Leads", icon: Users },
    { id: "analytics", label: "Stats", icon: BarChart3 },
  ]

  const moreItems = [
    { id: "chatbot-web-whatsapp", label: "Chatbot Web/WA", icon: MessageSquare },
    { id: "chatbot-voice", label: "Chatbot Voz", icon: Phone },
    { id: "avm-valuation", label: "Valoración AVM", icon: Home },
    { id: "document-automation", label: "Documentos", icon: FileText },
    { id: "partner-management", label: "Partners", icon: Handshake },
  ]

  const handleItemClick = (itemId: string) => {
    dispatch({ type: "SET_ACTIVE_MODULE", payload: itemId as any })
  }

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50">
      <div className="flex items-center justify-around">
        {mainItems.map((item) => {
          const isActive = state.activeModule === item.id
          return (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center space-y-1 h-auto py-2 px-3 ${
                isActive ? "text-indigo-600" : "text-gray-600"
              }`}
              onClick={() => handleItemClick(item.id)}
            >
              <div className="relative">
                <item.icon className="w-5 h-5" />
                {item.badge && item.badge > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-2 -right-2 w-4 h-4 p-0 flex items-center justify-center text-xs"
                  >
                    {item.badge}
                  </Badge>
                )}
              </div>
              <span className="text-xs">{item.label}</span>
            </Button>
          )
        })}

        {/* More Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="flex flex-col items-center space-y-1 h-auto py-2 px-3 text-gray-600"
            >
              <MoreHorizontal className="w-5 h-5" />
              <span className="text-xs">Más</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            {moreItems.map((item) => {
              const module = state.modules.find((m) => m.id === item.id)
              const isActive = module?.isActive !== false

              return (
                <DropdownMenuItem
                  key={item.id}
                  onClick={() => handleItemClick(item.id)}
                  disabled={!isActive}
                  className={!isActive ? "opacity-50" : ""}
                >
                  <item.icon className="w-4 h-4 mr-2" />
                  {item.label}
                </DropdownMenuItem>
              )
            })}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  )
}
