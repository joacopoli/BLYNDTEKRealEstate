"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Save, User, Building, Bell, Shield, Zap } from 'lucide-react'

export default function SettingsPanel() {
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    leads: true,
    conversations: true
  })

  const [profile, setProfile] = useState({
    name: "Juan Pérez",
    email: "juan@blyndtek.com",
    phone: "+34 600 123 456",
    role: "Administrador"
  })

  const [company, setCompany] = useState({
    name: "Blyndtek Real Estate",
    address: "Calle Mayor 123, Madrid",
    phone: "+34 91 123 4567",
    website: "www.blyndtek.com"
  })

  const handleSave = () => {
    console.log("Settings saved")
  }

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Configuración</h1>
          <p className="text-gray-500">Gestiona la configuración de tu cuenta y empresa</p>
        </div>
        <Button onClick={handleSave} className="bg-violet-600 hover:bg-violet-700">
          <Save className="w-4 h-4 mr-2" />
          Guardar Cambios
        </Button>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="company">Empresa</TabsTrigger>
          <TabsTrigger value="notifications">Notificaciones</TabsTrigger>
          <TabsTrigger value="security">Seguridad</TabsTrigger>
          <TabsTrigger value="integrations">Integraciones</TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2" />
                Información Personal
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nombre Completo</Label>
                  <Input
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile({...profile, name: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="role">Rol</Label>
                  <Input
                    id="role"
                    value={profile.role}
                    onChange={(e) => setProfile({...profile, role: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({...profile, email: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    value={profile.phone}
                    onChange={(e) => setProfile({...profile, phone: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="company">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building className="w-5 h-5 mr-2" />
                Información de la Empresa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="companyName">Nombre de la Empresa</Label>
                <Input
                  id="companyName"
                  value={company.name}
                  onChange={(e) => setCompany({...company, name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="address">Dirección</Label>
                <Textarea
                  id="address"
                  value={company.address}
                  onChange={(e) => setCompany({...company, address: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="companyPhone">Teléfono</Label>
                  <Input
                    id="companyPhone"
                    value={company.phone}
                    onChange={(e) => setCompany({...company, phone: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="website">Sitio Web</Label>
                  <Input
                    id="website"
                    value={company.website}
                    onChange={(e) => setCompany({...company, website: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                Preferencias de Notificaciones
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium">Canales de Notificación</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Notificaciones por Email</span>
                    <Switch
                      checked={notifications.email}
                      onCheckedChange={(checked) => setNotifications({...notifications, email: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Notificaciones Push</span>
                    <Switch
                      checked={notifications.push}
                      onCheckedChange={(checked) => setNotifications({...notifications, push: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Notificaciones SMS</span>
                    <Switch
                      checked={notifications.sms}
                      onCheckedChange={(checked) => setNotifications({...notifications, sms: checked})}
                    />
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="font-medium">Tipos de Notificación</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Nuevos Leads</span>
                    <Switch
                      checked={notifications.leads}
                      onCheckedChange={(checked) => setNotifications({...notifications, leads: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Nuevas Conversaciones</span>
                    <Switch
                      checked={notifications.conversations}
                      onCheckedChange={(checked) => setNotifications({...notifications, conversations: checked})}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Configuración de Seguridad
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium">Autenticación</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Autenticación de dos factores</span>
                    <Badge variant="outline">Desactivado</Badge>
                  </div>
                  <Button variant="outline" size="sm">
                    Configurar 2FA
                  </Button>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="font-medium">Sesiones Activas</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <p className="font-medium">Navegador actual</p>
                      <p className="text-sm text-gray-500">Chrome en Windows - Madrid, España</p>
                    </div>
                    <Badge variant="secondary">Activa</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="w-5 h-5 mr-2" />
                Integraciones y APIs
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium">Servicios Conectados</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <p className="font-medium">WhatsApp Business API</p>
                      <p className="text-sm text-gray-500">Conectado</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Activo</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <p className="font-medium">CRM Database</p>
                      <p className="text-sm text-gray-500">Sincronización automática</p>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Sincronizado</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
